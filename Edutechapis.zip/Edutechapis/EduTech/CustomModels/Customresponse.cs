﻿using System;
using System.ComponentModel.DataAnnotations;

namespace EduTech.CustomModels
{
    public class Customresponse
    {
        public int responsecode { get; set; }
        public string responsemessage { get; set; }
        public Guid authorid { get; set; }
        public Guid loginid { get; set; }
        public string token { get; set; }

    }


    public class Customresponselogin
    {
        public string loginType { get; set; }
        public int responsecode { get; set; }
        public string responsemessage { get; set; }
        public Guid authorid { get; set; }
        public Guid loginid { get; set; }
        public string token { get; set; }

    }







    public class Customlogin
    {
        public string username { get; set; }
        public string password { get; set; }
    }
    public class Customlogout
    {
        public Guid loginid { get; set; }
    }

    public class Customresetpassword
    {
        public Guid authorid { get; set; }
        [Required]
        public string newpassword { get; set; }
        public string confirmpassword { get; set; }
        [Required]
        public string currentpassword { get; set; }

    }


    public class CustomChangePassword
    {
        [Required]
        public Guid authorid { get; set; }
        [Required]
        public string newpassword { get; set; }
        [Required]
        public string confirmpassword { get; set; }

    }




    public class Newpassword
    {
        //public Guid id { get; set; }
        public string newpassword { get; set; }
        public string confirmpassword { get; set; }
        [Required]
        public string token { get; set; }
    }

    public class Customotp
    {
        public Guid authorid { get; set; }
        public string otp { get; set; }
    }
    public class Customforgetpassword
    {
        public string email { get; set; }
    }
    public class CustomIndex
    {
        public Guid authorid { get; set; }
    }

    public class CustomEditGet
    {
        public Guid authorid { get; set; }
        public Guid id { get; set; }
    }
}
