﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.CustomModels
{
    public class CustomSegment
    {
       
       [Required(ErrorMessage ="Please Enter Title")]
        public string title { get; set; }
        
       
        [Required(ErrorMessage = "please Sent author id")]
        public Guid authorid { get; set; }
       
       

    }
    public class CustomSegmentEdit
    {
        [Required(ErrorMessage = "Please Enter id")]
        public Guid id { get; set; }
       
        public string title { get; set; }
       
       
        [Required(ErrorMessage = "please Sent author id")]
        public Guid authorid { get; set; }
      
       
    }
    public class CustomSegmentDelete
    {
        [Required(ErrorMessage = "Please Enter id")]
        public Guid id { get; set; }
        [Required(ErrorMessage = "please Sent author id")]
        public Guid authorid { get; set; }
       
       
    }

}
