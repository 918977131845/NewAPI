﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.CustomModels
{
    public class Customquestiontype
    {
      
        public string name { get; set; }
        [Required(ErrorMessage = "please Sent author id")]
        public Guid authorid { get; set; }
    }
    public class Customquestiontypeedit: Customquestiontype
    {
        public Guid id { get; set; }
    }
    public class CustomquestiontypeDelete
    {
        [Required(ErrorMessage = "Please Enter id")]
        public Guid id { get; set; }
        [Required(ErrorMessage = "please Sent author id")]
        public Guid authorid { get; set; }


    }
}
