﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.CustomModels
{
    public class CustomadminCreate
    {
        public string Name { get; set; }
        public string address { get; set; }
        public double areacode { get; set; }
        public string email { get; set; }
        public string phone { get; set; }
        public string area { get; set; }
        public IFormFile image { get; set; }
        public string organizationname { get; set; }
        public string organizationinfomail { get; set; }
        public string organizationinfomailpassword { get; set; }
        [Required]
        public Nullable<Guid> authorid { get; set; }
        
    }
    public class CustomadminEdit
    {
        [Required]
        public Guid id { get; set; }
        public string Name { get; set; }
        public string address { get; set; }
        public double areacode { get; set; }
        public string email { get; set; }
        public string area { get; set; }
        public string phone { get; set; }
        public IFormFile image { get; set; }
        public string organizationname { get; set; }
        public string organizationinfomail { get; set; }
        public string organizationinfomailpassword { get; set; }
        [Required]
        public Nullable<Guid> authorid { get; set; }
       
    }
}
