﻿using System;
using System.ComponentModel.DataAnnotations;

namespace EduTech.CustomModels
{
    public class Customtopic
    {
        public Guid segmentid { get; set; }
        public Guid gradeid { get; set; }
        public Guid curriculumid { get; set; }
        public Guid subjectid { get; set; }
        public Guid assessmenttypeid { get; set; }
        public string topic_name { get; set; }
        [Required(ErrorMessage = "please Sent author id")]
        public Guid authorid { get; set; }
    }
    public class Customtopicedit : Customtopic
    {
        [Required(ErrorMessage = "Please Enter id")]
        public Guid id { get; set; }
    }
    public class CustomtopicDelete
    {
        [Required(ErrorMessage = "Please Enter id")]
        public Guid id { get; set; }
        [Required(ErrorMessage = "please Sent author id")]
        public Guid authorid { get; set; }


    }
}
