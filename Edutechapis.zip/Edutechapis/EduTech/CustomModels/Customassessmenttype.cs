﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.CustomModels
{
    public class Customassessmenttype

    {
        public Guid id { get; set; }
        public bool isactive { get; set; }
        public bool isdelete { get; set; }=false;
        public DateTime createdon { get; set; }
        public Guid createdby { get; set; }
        public DateTime Modifiedon { get; set; }
        public Guid modifiedby { get; set; }
        public Double Totalmarks { get; set; }
        public Double Eachquestion_correctmarks { get; set; }
        public Double Eachquestion_negativemarking { get; set; }
        public string instructions { get; set; }
        public Guid adminid { get; set; }
        public string Assessmenttype_name { get; set; }

        public Double TotalQuestions { get; set; }
        public DateTime Duration { get; set; }

        public DateTime PackageDuration { get; set; }
        public Double Price { get; set; }
        public Double MockTest { get; set; }
        public Double SubjectTest { get; set; }
        public Double Discount { get; set; }
        public int TopicWiseTest { get; set; }
        [Required]
        public Guid segmentid { get; set; }

        [Required]
        public Guid subjectid { get; set; }
        [Required]
        public Guid topicid { get; set; }
        [Required]
        public Guid gradeid { get; set; }
        [Required]
        public Guid curriculumid { get; set; }

    }
    public class Customassessmenttypeedit
    {
        public Guid id { get; set; }
        public Double Totalmarks { get; set; }
        public Double Eachquestion_correctmarks { get; set; }
        public Double Eachquestion_negativemarking { get; set; }
        public string instructions { get; set; }
        public Guid authorid { get; set; }
        public string Assessmenttype_name { get; set; }
    }
    public class Customassessmenttypedelete
    {
        [Required(ErrorMessage = "Please Enter id")]
        public Guid id { get; set; }
        [Required(ErrorMessage = "please Sent author id")]
        public Guid authorid { get; set; }

    }
}
  
