﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace EduTech.CustomModels
{
    public class Customstudents
    {
        public string name { get; set; }
        public string email { get; set; }
        public string mobilenumber { get; set; }
        public string grade { get; set; }
        public string course { get; set; }
      //  public string password { get; set; }
        public string parentname { get; set; }
        public string parentemail { get; set; }
        public string parentmobile { get; set; }
        public string dateofbirth { get; set; }
        public string address { get; set; }
        public string studenttype { get; set; }
        public IFormFile profilepic { get; set; }
        public Guid authorid { get; set; }
        [JsonIgnore]
        public string parentphone { get; set; }
    }
    public class Customstudentsedit
    {
        public Guid id { get; set; }
        public string name { get; set; }
        public string email { get; set; }
        public string mobilenumber { get; set; }
        public string grade { get; set; }
        public string course { get; set; }
        public string password { get; set; }
        public string parentname { get; set; }
        public string parentemail { get; set; }
        public string parentmobile { get; set; }
        public string dateofbirth { get; set; }
        public string address { get; set; }
        public string studenttype { get; set; }
        public IFormFile profilepic { get; set; }
        public Guid authorid { get; set; }
    }
}
