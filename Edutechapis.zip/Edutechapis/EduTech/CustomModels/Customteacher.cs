﻿using System;
using System.ComponentModel.DataAnnotations;

namespace EduTech.CustomModels
{

    public class Customteachercreate
    {
        public string name { get; set; }
        public string email { get; set; }
        public string mobilenumber { get; set; }
        public string course { get; set; }
        //public string subject { get; set; }

        public DateTime DateOfBirth { get; set; }
        public string Address { get; set; }

        [Required]
        public Nullable<Guid> authorid { get; set; }

    }


    public class Customteacher
    {
        public Guid id { get; set; }
        public string name { get; set; }
        public string email { get; set; }
        public string mobilenumber { get; set; }
        public string course { get; set; }
        public string subject { get; set; }


        [Required]
        public Nullable<Guid> authorid { get; set; }

    }
}
