﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace EduTech.CustomModels
{
    public class CustomExamDay
    {
        [Required(ErrorMessage = "Please Enter id")]
        public Guid id { get; set; }
        [Required]
        public string emailid { get; set; }
        [Required]
        public Guid Assessmentid { get; set; }
    }
}
