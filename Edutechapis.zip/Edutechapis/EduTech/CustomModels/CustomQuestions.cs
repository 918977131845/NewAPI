﻿using System.Collections.Generic;

namespace EduTech.CustomModels
{
    public class CustomQuestions
    {
        public List<string> questionImages { get; set; }
        public List<ExcelAnswer> excelAnswers { get; set; }
        //public string level { get; set; }
    }
    public class ExcelAnswer
    {
        public string Answers { get; set; }
    }
}
