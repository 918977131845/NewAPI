﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace EduTech.CustomModels
{
    public class Customquestion:CustomQuestions
    {
        public Guid? Assessmentid { get; set; }
        public Guid? questiontype { get; set; }
        public Guid? segmentid { get; set; }
        public Guid? subjectid { get; set; }
        public Guid? topicid { get; set; }
        public string level { get; set; }
        [JsonIgnore]
        public string questionname { get; set; }
        public Guid? gradeid { get; set; }
        public Guid? curriculumid { get; set; }
        [JsonIgnore]
        public string correctanswer { get; set; }
        [Required(ErrorMessage = "please Sent author id")]
        public Guid authorid { get; set; }
        [JsonIgnore]
        public string questiondata { get; set; }    
    }
    public class Customquestioncreate: Customquestion
    {
       // public List<IFormFile> Bulkimage { get; set; }
    }
    public class Customquestionedit : Customquestion
    {
        public Guid id { get; set; }
        public IFormFile Bulkimage { get; set; }
    }
    public class Customquestiondelete
    {
        [Required(ErrorMessage = "Please Enter id")]
        public Guid id { get; set; }
        [Required(ErrorMessage = "please Sent author id")]
        public Guid authorid { get; set; }

    }
}
