﻿using EduTech.CustomModels;
using EduTech.Data;
using EduTech.IServices;
using EduTech.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.Services
{
    public class Studentservices : IStudentservices
    {
        private readonly ApplicationDbContext _Db;
        private readonly ISentEmailSms _sentEmailSms;
        private readonly IAws3Services _aws3servies;
        public Studentservices(ApplicationDbContext Db, IAws3Services aws3services, ISentEmailSms sentEmailSms)
        {
            _Db = Db;
            _aws3servies = aws3services;
            _sentEmailSms = sentEmailSms;
        }

        public async Task<Customresponse> PostForgetpassword(Customforgetpassword cc)
        {
            try
            {
                var Getdata = _Db.students.Where(x => x.isdeleted == false && x.isactive == true && x.email == cc.email).SingleOrDefault();
                if (Getdata != null)
                {
                    var otp = _sentEmailSms.forgetpasswordotp(Getdata.name, Getdata.email, Getdata.mobilenumber);
                    Getdata.otp = otp;
                    _Db.Entry(Getdata).State = EntityState.Modified;
                    await _Db.SaveChangesAsync();
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 1;
                    cr.responsemessage = "Otp Successfully Sent";
                    cr.authorid = Getdata.id;
                    return cr;
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "emailid invalid";
                    return cr;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Customresponse> postresetpassword(Customresetpassword cc)
        {
            try
            {
                if(cc.currentpassword== _Db.students.Where(x => x.isdeleted == false && x.isactive == true && x.id == cc.authorid).Select(p=>p.password).SingleOrDefault())
                {
                    if (cc.newpassword == cc.confirmpassword)
                    {
                        var getdata = _Db.students.Where(x => x.isdeleted == false && x.isactive == true && x.id == cc.authorid).SingleOrDefault();
                        if (getdata != null)
                        {
                            getdata.password = cc.confirmpassword;
                            getdata.updatedby = cc.authorid;
                            getdata.updatedon = System.DateTimeOffset.Now;
                            _Db.Entry(getdata).State = EntityState.Modified;
                            await _Db.SaveChangesAsync();
                            Customresponse cr = new Customresponse();
                            cr.responsecode = 1;
                            cr.responsemessage = "Password Successfully Updated";
                            return cr;
                        }
                        else
                        {
                            Customresponse cr = new Customresponse();
                            cr.responsecode = 2;
                            cr.responsemessage = "authorid cann't be null";
                            return cr;
                        }
                    }
                    else
                    {
                        Customresponse cr = new Customresponse();
                        cr.responsecode = 2;
                        cr.responsemessage = "newpassword and confirmpassword doesn't match";
                        return cr;
                    }
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "Please enter the current correct password";
                    return cr;
                }

            }
            catch (Exception)
            {
                throw;
            }
        }



        public async Task<Customresponse> postchangepassword(CustomChangePassword cc)
        {
            try
            {

                if (cc.newpassword == cc.confirmpassword)
                {
                    var getdata = _Db.students.Where(x => x.isdeleted == false && x.isactive == true && x.id == cc.authorid).SingleOrDefault();
                    if (getdata != null)
                    {
                        getdata.password = cc.confirmpassword;
                        getdata.updatedby = cc.authorid;
                        getdata.updatedon = System.DateTime.Now;
                        _Db.Entry(getdata).State = EntityState.Modified;
                        await _Db.SaveChangesAsync();
                        Customresponse cr = new Customresponse();
                        cr.responsecode = 1;
                        cr.responsemessage = "Password Successfully Updated";
                        return cr;
                    }
                    else
                    {
                        Customresponse cr = new Customresponse();
                        cr.responsecode = 2;
                        cr.responsemessage = "authorid cann't be null";
                        return cr;
                    }
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "newpassword and confirmpassword doesn't match";
                    return cr;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }






        public async Task<Customresponse> studentcreate(Customstudents model)
        {
            try
            {
                var Getstudentemail = _Db.students.Where(x => x.isdeleted == false && x.isactive == true && x.email == model.email).SingleOrDefault();
                if (Getstudentemail == null)
                {
                    var Getstudentphone = _Db.students.Where(x => x.isdeleted == false && x.isactive == true && x.mobilenumber == model.mobilenumber).SingleOrDefault();
                    if (Getstudentphone == null)
                    {
                        students gg = new students();
                        gg.id = Guid.NewGuid();
                        gg.isactive = true;
                        gg.isdeleted = false;
                        gg.createdby = model.authorid;
                        gg.createdon = System.DateTimeOffset.Now;
                        gg.updatedby = model.authorid;
                        gg.updatedon = System.DateTimeOffset.Now;
                        gg.course = model.course;
                        gg.name = model.name;
                        gg.email = model.email;
                        gg.mobilenumber = model.mobilenumber;
                        gg.grade = model.grade;
                        Random rr = new Random();
                        gg.password = Convert.ToString(rr.Next(1, 1000000));
                        var allChar = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
                        var random = new Random();
                        var resultToken = new string(
                           Enumerable.Repeat(allChar, 8)
                           .Select(token => token[random.Next(token.Length)]).ToArray());

                        string authToken = resultToken.ToString();
                        gg.token = authToken;
                        gg.dateofbirth = model.dateofbirth;
                        gg.address = model.address;
                        gg.studenttype = model.studenttype;
                        gg.parentemail = model.parentemail;
                        gg.parentname = model.parentname;
                        gg.parentphone = model.parentphone;
                        if (model.profilepic != null)
                        {
                            string uniqueFileName = _aws3servies.PostUploadedFile(model.profilepic);
                            gg.profilepic = "https://s3edutech.s3.ap-south-1.amazonaws.com/" + uniqueFileName + "";
                        }
                        _Db.students.Add(gg);
                        await _Db.SaveChangesAsync();
                        _sentEmailSms.SendEmailTecherORStudent(gg.name, gg.email, gg.token);
                        Customresponse cr = new Customresponse();
                        cr.responsecode = 1;
                        cr.responsemessage = "Created Successfully";
                        return cr;
                    }
                    else
                    {
                        Customresponse cr = new Customresponse();
                        cr.responsecode = 2;
                        cr.responsemessage = "mobile number already exists";
                        return cr;
                    }
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "email already exists";
                    return cr;
                }
            }
            catch(Exception)
            {
                throw;
            }
        }

        public async Task<Customresponse> studentcreatebystudent(Customstudents model)
        {
            try
            {
                var Getstudentemail = _Db.students.Where(x => x.isdeleted == false && x.isactive == true && x.email == model.email).SingleOrDefault();
                if (Getstudentemail == null)
                {
                    var Getstudentphone = _Db.students.Where(x => x.isdeleted == false && x.isactive == true && x.mobilenumber == model.mobilenumber).SingleOrDefault();
                    if (Getstudentphone == null)
                    {
                        students gg = new students();
                        gg.id = Guid.NewGuid();
                        gg.isactive = true;
                        gg.isdeleted = false;
                        gg.createdby = gg.id;
                        gg.createdon = System.DateTimeOffset.Now;
                        gg.updatedby = gg.id;
                        gg.updatedon = System.DateTimeOffset.Now;
                        gg.course = model.course;
                        gg.name = model.name;
                        gg.email = model.email;
                        gg.mobilenumber = model.mobilenumber;
                        gg.grade = model.grade;
                        Random rr = new Random();
                        gg.password = Convert.ToString(rr.Next(1, 1000000));
                        gg.dateofbirth = model.dateofbirth;
                        gg.address = model.address;
                        gg.studenttype = model.studenttype;
                        gg.parentemail = model.parentemail;
                        gg.parentname = model.parentname;
                        gg.parentmobile = model.parentmobile;
                        if (model.profilepic != null)
                        {
                            string uniqueFileName = _aws3servies.PostUploadedFile(model.profilepic);
                            gg.profilepic = "https://s3edutech.s3.ap-south-1.amazonaws.com/" + uniqueFileName + "";
                        }
                        _Db.students.Add(gg);
                        await _Db.SaveChangesAsync();
                        _sentEmailSms.SuperadminSentEmailSms(gg.name, gg.email, gg.password, gg.mobilenumber);
                        Customresponse cr = new Customresponse();
                        cr.responsecode = 1;
                        cr.responsemessage = "Created Successfully";
                        return cr;
                    }
                    else
                    {
                        Customresponse cr = new Customresponse();
                        cr.responsecode = 2;
                        cr.responsemessage = "mobile number already exists";
                        return cr;
                    }
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "email already exists";
                    return cr;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Customresponse> studentDelete(string id, string authorid)
        {
            try
            {
                var Getid = _Db.students.Where(x => x.isdeleted == false && x.isactive == true && x.id == new Guid(id)).SingleOrDefault();
                if (Getid != null)
                {
                    Getid.isdeleted = true;
                    Getid.updatedby = new Guid(authorid);
                    Getid.updatedon = System.DateTimeOffset.Now;
                    _Db.Entry(Getid).State = (Microsoft.EntityFrameworkCore.EntityState.Modified);
                    await _Db.SaveChangesAsync();
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 1;
                    cr.responsemessage = "Deleted Successfully";
                    return cr;
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "id is invalid or already deleted";
                    return cr;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Customresponse> studentEdit(Customstudentsedit model)
        {
            try
            {
                var Getemail = _Db.students.Where(x => x.isdeleted == false && x.isactive == true && x.id != model.id && x.email == model.email).SingleOrDefault();
                if (Getemail == null)
                {
                    var Getphone = _Db.students.Where(x => x.isdeleted == false && x.isactive == true && x.id != model.id && x.mobilenumber == model.mobilenumber).SingleOrDefault();
                    if (Getphone == null)
                    {
                        var gg = _Db.students.Where(x => x.isdeleted == false && x.isactive == true && x.id == model.id).SingleOrDefault();
                        if (gg != null)
                        {
                            gg.updatedby = model.authorid;
                            gg.updatedon = System.DateTimeOffset.Now;
                            gg.name = model.name;
                            gg.email = model.email;
                            gg.mobilenumber = model.mobilenumber;
                            gg.grade = model.grade;
                            gg.dateofbirth = model.dateofbirth;
                            gg.address = model.address;
                            gg.studenttype = model.studenttype;
                            gg.parentemail = model.parentemail;
                            gg.parentname = model.parentname;
                            gg.parentmobile = model.parentmobile;
                            if (model.profilepic != null)
                            {
                                string uniqueFileName = _aws3servies.PostUploadedFile(model.profilepic);
                                gg.profilepic = "https://s3edutech.s3.ap-south-1.amazonaws.com/" + uniqueFileName + "";
                            }
                            _Db.Entry(gg).State = (Microsoft.EntityFrameworkCore.EntityState.Modified);
                            await _Db.SaveChangesAsync();
                            Customresponse cr = new Customresponse();
                            cr.responsecode = 1;
                            cr.responsemessage = "Updated Successfully";
                            return cr;
                        }
                        else
                        {
                            Customresponse cr = new Customresponse();
                            cr.responsecode = 2;
                            cr.responsemessage = "Invalid id";
                            return cr;
                        }
                    }
                    else
                    {
                        Customresponse cr = new Customresponse();
                        cr.responsecode = 2;
                        cr.responsemessage = "Phone Already in Use";
                        return cr;
                    }
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "Email Already in Use";
                    return cr;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<IEnumerable<students>> studentsGetAll()
        {
            try
            {
                return await _Db.students.Where(x => x.isdeleted == false && x.isactive == true).ToListAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<IEnumerable<students>> studentsGetByauthor(string authorid)
        {
            try
            {
                return await _Db.students.Where(x => x.isdeleted == false && x.isactive == true && x.createdby == new Guid(authorid)).ToListAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<students> studentsGetbyId(string id)
        {
            try
            {
                return await _Db.students.Where(x => x.isdeleted == false && x.isactive == true && x.id == new Guid(id)).SingleOrDefaultAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
