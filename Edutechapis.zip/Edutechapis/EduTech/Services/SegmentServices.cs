﻿using EduTech.CustomModels;
using EduTech.Data;
using EduTech.IServices;
using EduTech.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace EduTech.Services
{
    public class SegmentServices : ISegmentServices
    {
        private readonly ApplicationDbContext _Db;
        private readonly IAws3Services _aws3servies;
        public SegmentServices(ApplicationDbContext Db, IAws3Services aws3services)
        {
            _Db = Db;
            _aws3servies = aws3services;
        }
        private static TimeZoneInfo INDIAN_ZONE = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
        DateTime indianTime = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
        public async Task<Customresponse> PostCreate(CustomSegment cc)
        {
            try
            {
                segment sc = new segment();
                sc.id = Guid.NewGuid();
                sc.createdby = cc.authorid;
                sc.createdon = indianTime;
                sc.updatedby = cc.authorid;
                sc.updatedon = indianTime;
                sc.isactive = true;
                sc.isdelete = false;
                sc.title = cc.title;
                
                var admin = _Db.admin.Where(x => x.isdeleted == false && x.isactive == true && x.id == cc.authorid).SingleOrDefault();
                var teacher = _Db.teacher.Where(x => x.isdeleted == false && x.isactive == true && x.id == cc.authorid).SingleOrDefault();
                if (admin != null)
                {
                    sc.adminid = admin.id;
                }
                else
                {
                    sc.adminid = (Guid)teacher.createdby;
                }
               
                _Db.segment.Add(sc);
                await _Db.SaveChangesAsync();
                Customresponse cr = new Customresponse();
                cr.responsecode = 1;
                cr.responsemessage = "Created Successfully";
                return cr;

            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Customresponse> PostEdit(CustomSegmentEdit cc)
        {
            try
            {
                var Getdata = _Db.segment.Where(x => x.isdelete == false && x.isactive == true && x.id == cc.id).SingleOrDefault();
                if (Getdata != null)
                {
                    Getdata.updatedby = cc.authorid;
                    Getdata.updatedon = indianTime;
                    Getdata.title = cc.title;
                   
                    _Db.Entry(Getdata).State = (Microsoft.EntityFrameworkCore.EntityState.Modified);
                    await _Db.SaveChangesAsync();
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 1;
                    cr.responsemessage = "Updated Successfully";
                    return cr;
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "id is incorrect";
                    return cr;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Customresponse> PostDelete(CustomSegmentDelete cc)
        {
            try
            {
                var Getdata = _Db.segment.Where(x => x.isdelete == false && x.isactive == true && x.id == cc.id).SingleOrDefault();
                if (Getdata != null )
                {
                    Getdata.isdelete = true;
                    Getdata.updatedon = indianTime;
                    Getdata.updatedby = cc.authorid;
                    _Db.Entry(Getdata).State = (Microsoft.EntityFrameworkCore.EntityState.Modified);
                    await _Db.SaveChangesAsync();
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 1;
                    cr.responsemessage = "Deleted Successfully";
                    return cr;
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "id is incorrect";
                    return cr;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<IEnumerable<segment>> GetAllsegment()
        {
            try
            {
                return await _Db.segment.Where(x => x.isdelete == false && x.isactive == true).OrderByDescending(x => x.createdon).ToListAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<segment> GetIdsegment(Guid id)
        {
            try
            {
                return await _Db.segment.Where(x => x.isdelete == false && x.isactive == true && x.id == id).SingleOrDefaultAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<IEnumerable<segment>> GetsegmentByauthorid(string authorid)
        {
            try
            {
                return await _Db.segment.Where(x => x.isdelete == false && x.isactive == true && x.createdby == new Guid(authorid)).ToListAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<IEnumerable<segment>> Getsegmentbyadminid(Guid authorid)
        {
            try
            {
                return await _Db.segment.Where(x => x.isdelete == false && x.isactive == true && x.adminid == authorid).ToListAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
