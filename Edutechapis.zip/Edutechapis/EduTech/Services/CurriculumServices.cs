﻿using EduTech.CustomModels;
using EduTech.Data;
using EduTech.IServices;
using EduTech.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.Services
{
    public class CurriculumServices : ICurriculumservices
    {
        private readonly ApplicationDbContext _Db;
        private readonly IAws3Services _aws3servies;
        public CurriculumServices(ApplicationDbContext Db, IAws3Services aws3services)
        {
            _Db = Db;
            _aws3servies = aws3services;
        }
        private static TimeZoneInfo INDIAN_ZONE = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
        DateTime indianTime = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);


       
        public async Task<Customresponse> PostCreate(CustomCurriculum cc)
        {
            try
            {
                curriculum gg = new curriculum();
                gg.id = Guid.NewGuid();
                gg.isactive = true;
                gg.isdelete = false;
                gg.createdby = cc.authorid;
                gg.createdon = indianTime;
                gg.updatedby = cc.authorid;
                gg.updatedon = indianTime;
                gg.title = cc.title;
                gg.segmentid = cc.segmentid;
                gg.gradeid = cc.gradeid;
                var Getadmin = _Db.admin.Where(x => x.isdeleted == false && x.id == cc.authorid).SingleOrDefault();
                var Getteacher = _Db.teacher.Where(x => x.isdeleted == false && x.id == cc.authorid).SingleOrDefault();
                if (Getadmin != null)
                {
                    gg.adminid = Getadmin.id;
                }
                else
                {
                    gg.adminid = Getteacher.createdby;
                }
                
                _Db.curriculum.Add(gg);
                await _Db.SaveChangesAsync();
                Customresponse cr = new Customresponse();
                cr.responsecode = 1;
                cr.responsemessage = "Created Successfully";
                return cr;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Customresponse> PostDelete(CustomCurriculumDelete cc)
        {
            try
            {
                var gg = _Db.curriculum.Where(x => x.isdelete == false && x.isactive == true && x.id == cc.id).SingleOrDefault();
                if (gg != null)
                {
                    gg.isdelete = true;
                    gg.updatedby = cc.authorid;
                    gg.updatedon = indianTime;
                    _Db.Entry(gg).State = (Microsoft.EntityFrameworkCore.EntityState.Modified);
                    await _Db.SaveChangesAsync();
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 1;
                    cr.responsemessage = "Deleted Successfully";
                    return cr;
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "id is incorrect";
                    return cr;
                }

            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Customresponse> PostEdit(CustomCurriculumEdit cc)
        {
            try
            {
                var gg = _Db.curriculum.Where(x => x.isdelete == false && x.isactive == true && x.id == cc.id).SingleOrDefault();
                if (gg != null)
                {
                    gg.updatedby = cc.authorid;
                    gg.updatedon = indianTime;
                    gg.title = cc.title;
                  
                    gg.segmentid = cc.segmentid;
                    gg.gradeid = cc.gradeid;
                    _Db.Entry(gg).State = (Microsoft.EntityFrameworkCore.EntityState.Modified);
                    await _Db.SaveChangesAsync();
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 1;
                    cr.responsemessage = "Updated Successfully";
                    return cr;
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "id is incorrect";
                    return cr;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<IEnumerable<curriculum>> GetAllCurriculum()
        {
            try
            {
                return await _Db.curriculum.Where(x => x.isdelete == false && x.isactive == true).ToListAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<curriculum> GetIdCurriculum(Guid id)
        {
            try
            {
                return await _Db.curriculum.Where(x => x.isdelete == false && x.isactive == true && x.id == id).SingleOrDefaultAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public  async Task<IEnumerable<curriculum>> GetCurriculumByauthorid(string authorid)
        {
            try
            {
                return await _Db.curriculum.Where(x => x.isdelete == false && x.isactive == true && x.createdby == new Guid(authorid)).ToListAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<IEnumerable<curriculum>> GetCurriculumbyadminid(Guid authorid)
        {
            try
            {
                return await _Db.curriculum.Where(x => x.isdelete == false && x.isactive == true && x.createdby == authorid).ToListAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
