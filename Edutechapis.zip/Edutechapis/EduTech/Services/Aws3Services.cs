﻿using Amazon;
using Amazon.S3;
using Amazon.S3.Transfer;
using EduTech.IServices;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using System;
using System.IO;

namespace EduTech.Services
{
    public class Aws3Services : IAws3Services
    {
        private readonly string _bucketName;
        private readonly IAmazonS3 _awsS3Client;
        private readonly IAppConfiguration _appConfiguration;
        private readonly IHostingEnvironment _HostEnvironment;

        public Aws3Services(IAppConfiguration appConfiguration, IHostingEnvironment HostEnvironment)
        {
            _HostEnvironment= HostEnvironment;  
            _appConfiguration = appConfiguration;
            _bucketName = _appConfiguration.BucketName;
            _awsS3Client = new AmazonS3Client(_appConfiguration.AwsAccessKey, _appConfiguration.AwsSecretAccessKey, RegionEndpoint.GetBySystemName(_appConfiguration.Region));
        }

        public string PostUploadedFile(string fileName, IFormFile image)
        {
            try
            {
                string webRootPath = _HostEnvironment.WebRootPath;
                string contentRootPath = _HostEnvironment.ContentRootPath;

                var path = "";
                path = Path.Combine(webRootPath, "DisplayImages");
                  MemoryStream memoryStream = new MemoryStream();
                    image.CopyTo(memoryStream);
                TransferUtility transferUtility = new TransferUtility(_awsS3Client);
                TransferUtilityUploadRequest transferUtilityUploadRequest = new TransferUtilityUploadRequest();

                transferUtilityUploadRequest.InputStream=memoryStream;
                transferUtilityUploadRequest.Key = Path.GetFileName(fileName);
                transferUtilityUploadRequest.BucketName = _bucketName;
                //transferUtilityUploadRequest.FilePath = path+"\\"+ fileName;
                transferUtilityUploadRequest.StorageClass = S3StorageClass.StandardInfrequentAccess;
                transferUtilityUploadRequest.CannedACL = S3CannedACL.PublicRead;
                transferUtilityUploadRequest.ContentType = "image/jpeg";

                transferUtility.Upload(transferUtilityUploadRequest);
                //transferUtility.Dispose();

                return fileName;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public string PostUploadedFile(IFormFile image)
        {
            try
            {
                string uniqueFileName = null;
                uniqueFileName = Guid.NewGuid().ToString();

                using (var newMemoryStream = new MemoryStream())
                {
                    image.CopyTo(newMemoryStream);


                    TransferUtilityUploadRequest transferUtilityUploadRequest = new TransferUtilityUploadRequest();

                    transferUtilityUploadRequest.InputStream = newMemoryStream;
                    transferUtilityUploadRequest.Key = uniqueFileName;
                    transferUtilityUploadRequest.BucketName = _bucketName;

                    transferUtilityUploadRequest.ContentType = "image/jpeg";//image.ContentType;

                    //var uploadRequest = new TransferUtilityUploadRequest
                    //{
                       
                    //    InputStream = newMemoryStream,
                    //    Key = uniqueFileName,
                    //    BucketName = _bucketName,
                    //    ContentType = image.ContentType
                    //};

                    var fileTransferUtility = new TransferUtility(_awsS3Client);

                    fileTransferUtility.Upload(transferUtilityUploadRequest);

                    return uniqueFileName;
                }

            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}

