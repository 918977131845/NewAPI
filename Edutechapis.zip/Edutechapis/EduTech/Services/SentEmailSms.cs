﻿using EduTech.IServices;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

namespace EduTech.Services
{
    public class SentEmailSms : ISentEmailSms
    {
        public string forgetpasswordotp(string name, string email, string phone)
        {
            try
            {
                string otp = null;
                Random generator = new Random();
                string apppassword = generator.Next(0, 9999).ToString("D4");

                string MessageEmail = "Hello Mr. / Mrs. " + name + " , please use this OTP " + apppassword + " to Sign In .";
                MailMessage messagesEmail = new MailMessage();
                messagesEmail.IsBodyHtml = true;
                messagesEmail.Subject = "Edutech Credential";
                messagesEmail.To.Add(email);
                messagesEmail.Body = MessageEmail;
                messagesEmail.From = new MailAddress("info@annamrajus.com", "Edutech");
                SmtpClient clients = new SmtpClient("smtp.sendgrid.net");// for localhost
                clients.UseDefaultCredentials = false;
                clients.Credentials = new NetworkCredential("apikey", "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");
                clients.DeliveryMethod = SmtpDeliveryMethod.Network;
                clients.Port = 587; // I have tried with 25 and 2525
                                    //clients.Port = 587; // localhost
                clients.Timeout = 99999;
                clients.EnableSsl = false;
                clients.Send(messagesEmail);


                string Msg = "Use " + apppassword + " as one time password to proceed further, " + name + " ANMRJU";
                WebClient client = new WebClient();
                string baseurl = "https://prpsms.co.in/API/SendMsg.aspx?uname=20200954&pass=LYo9vVTC&send=ANMRJU&dest=" + phone + "&msg=" + Msg + "";
                Stream data = client.OpenRead(baseurl);
                StreamReader reader = new StreamReader(data);
                string s = reader.ReadToEnd();
                data.Close();
                reader.Close();
                otp = apppassword;
                return otp;
            }
            catch (Exception)
            {
                throw;
            }
        }


        public void SendEmailTecherORStudent(string name,string email,string token)
        {
            try
            {
                string tempToken = "https://exam.edutechexpariksa.com/newpassword.html?token=" + token;
                string MessageEmail= @"<div>Dear "+name+ ",</div> <br/><div>Your registration process on pariksha platform has been completed. Please use below credentials for signin </div> <br> <div> username :" + email+ " <br/>password :<a href='" + tempToken + "' target='_blank'>generate password link</a></div> <br/> Regards, <br/>Team Pariksha.";

              //"Hello Mr./Mrs." + name + " Your Registration Process has been Completed,  Please use " + email + " as username and " + password + " as password for Sign in. ";
                MailMessage messagesEmail = new MailMessage();
                messagesEmail.IsBodyHtml = true;
                messagesEmail.Subject = "Edutech Credential";
                messagesEmail.To.Add(email);
                messagesEmail.Body = MessageEmail;
                messagesEmail.From = new MailAddress("info@annamrajus.com", "Edutech");
                SmtpClient clients = new SmtpClient("smtp.sendgrid.net");// for localhost
                clients.UseDefaultCredentials = false;
                clients.Credentials = new NetworkCredential("apikey", "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");
                clients.DeliveryMethod = SmtpDeliveryMethod.Network;
                clients.Port = 587; // I have tried with 25 and 2525
                                    //clients.Port = 587; // localhost
                clients.Timeout = 99999;
                clients.EnableSsl = false;
                clients.Send(messagesEmail);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void SuperadminSentEmailSms(string name,string email,string password,string phone)
        {
            try
            {
                string MessageEmail = "Hello Mr./Mrs." + name + " Your Registration Process has been Completed,  Please use " + email + " as username and " + password + " as password for Sign in. ";
                MailMessage messagesEmail = new MailMessage();
                messagesEmail.IsBodyHtml = true;
                messagesEmail.Subject = "Edutech Credential";
                messagesEmail.To.Add(email);
                messagesEmail.Body = MessageEmail;
                messagesEmail.From = new MailAddress("info@annamrajus.com", "Edutech");
                SmtpClient clients = new SmtpClient("smtp.sendgrid.net");// for localhost
                clients.UseDefaultCredentials = false;
                clients.Credentials = new NetworkCredential("apikey", "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");
                clients.DeliveryMethod = SmtpDeliveryMethod.Network;
                clients.Port = 587; // I have tried with 25 and 2525
                                    //clients.Port = 587; // localhost
                clients.Timeout = 99999;
                clients.EnableSsl = false;
                clients.Send(messagesEmail);


                //string Msg = "Hello Mr./Mrs." + name + " Your Registration Process has been Completed,  Please use " + username + " as username and " + password + " as password for Sign in. ANMRJU";
                //WebClient client = new WebClient();
                //string baseurl = "https://prpsms.co.in/API/SendMsg.aspx?uname=20200954&pass=LYo9vVTC&send=SMSINF&dest=" + phone + "" + "&msg=" + Msg + "";
                //Stream data = client.OpenRead(baseurl);
                //StreamReader reader = new StreamReader(data);
                //string s = reader.ReadToEnd();
                //data.Close();
                //reader.Close();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
