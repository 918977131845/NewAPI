﻿using EduTech.CustomModels;
using EduTech.Data;
using EduTech.IServices;
using EduTech.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.Services
{
    public class questiontypeservices : Iquestiontypeservices
    {
        private static TimeZoneInfo INDIAN_ZONE = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
        DateTime indianTime = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);

        private readonly ApplicationDbContext _Db;
        private readonly IAws3Services _aws3servies;
        public questiontypeservices(ApplicationDbContext Db, IAws3Services aws3services)
        {
            _Db = Db;
            _aws3servies = aws3services;
        }
        public async Task<Customresponse> Create(Customquestiontype cc)
        {
            try
            {
                question_type cs = new question_type();
                cs.id = Guid.NewGuid();
                cs.isactive = true;
                cs.isdelete = false;
                cs.createdby = cc.authorid;
                cs.createdon = indianTime;
                cs.modifiedby = cc.authorid;
                cs.modifiedon = indianTime;
                cs.name = cc.name;
                _Db.question_type.Add(cs);
                await _Db.SaveChangesAsync();
                Customresponse cr = new Customresponse();
                cr.responsecode = 1;
                cr.responsemessage = "Created Successfully";
                return cr;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Customresponse> Delete(CustomquestiontypeDelete cc)
        {
            try
            {
                var Getid = _Db.question_type.Where(x => x.isdelete == false && x.isactive == true && x.id == cc.id).SingleOrDefault();
                if (Getid != null)
                {
                    Getid.isdelete = true;
                    Getid.modifiedby = cc.authorid;
                    Getid.modifiedon = indianTime;
                    _Db.Entry(Getid).State = (Microsoft.EntityFrameworkCore.EntityState.Modified);
                    await _Db.SaveChangesAsync();
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 1;
                    cr.responsemessage = "Deleted Successfully";
                    return cr;
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "id is incorrect";
                    return cr;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Customresponse> Edit(Customquestiontypeedit cc)
        {
            try
            {
                var Getid = _Db.question_type.Where(x => x.isdelete == false && x.isactive == true && x.id == cc.id).SingleOrDefault();
                if (Getid != null)
                {
                    Getid.name = cc.name;
                    Getid.modifiedby = cc.authorid;
                    Getid.modifiedon = indianTime;
                    _Db.Entry(Getid).State = (Microsoft.EntityFrameworkCore.EntityState.Modified);
                    await _Db.SaveChangesAsync();
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 1;
                    cr.responsemessage = "Updated Successfully";
                    return cr;
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "id is incorrect";
                    return cr;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<IEnumerable<question_type>> Getallquestiontype()
        {
            try
            {
                return await _Db.question_type.Where(x => x.isdelete == false && x.isactive == true).ToListAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<question_type> Getquestiontypebyid(string id)
        {
            try
            {
                return await _Db.question_type.Where(x => x.isdelete == false && x.isactive == true && x.id == new Guid(id)).SingleOrDefaultAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
