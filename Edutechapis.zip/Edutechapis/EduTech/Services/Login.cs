﻿using EduTech.CustomModels;
using EduTech.Data;
using EduTech.IServices;
using EduTech.Models;
using System;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.Services
{
    public class Login : ILogin
    {
        private readonly ApplicationDbContext _Db;
        private readonly IJwttokenmanager _jwt;
        public Login(ApplicationDbContext Db, IJwttokenmanager jwt)
        {
            _Db = Db;
            _jwt = jwt;
         
        }

        public async Task<Customresponse> postlogin(Guid id)
        {
            try
            {
                var Getdata = _Db.userlog.Where(x => x.isactive == true && x.userid == id).SingleOrDefault();
                if (Getdata == null)
                {
                    userlog aa = new userlog();
                    aa.id = Guid.NewGuid();
                    aa.userid = id;
                    aa.login = System.DateTime.Now;
                    aa.isactive = true;
                    var tok = _jwt.Authenticate(aa.id.ToString());
                    await _Db.userlog.AddAsync(aa);
                    _Db.SaveChanges();
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 1;
                    cr.responsemessage = "Login Successfully";
                    cr.authorid = id;
                    cr.loginid = aa.id;
                    cr.token = tok;
                    return cr;
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 3;
                    cr.responsemessage = "You are Already Login";
                    cr.authorid = id;
                    cr.loginid = Getdata.id;
                    return cr;
                }
                
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Customresponse> postlogout(Guid loginid)
        {
            var Getlog = _Db.userlog.Where(x => x.isactive == true && x.id == loginid).SingleOrDefault();
            if (Getlog != null)
            {
                Getlog.isactive = false;
                Getlog.logout = System.DateTime.Now;
                _Db.Entry(Getlog).State = EntityState.Modified;
                await _Db.SaveChangesAsync();
                Customresponse cr = new Customresponse();
                cr.responsecode = 1;
                cr.responsemessage = "LogOut Successfully";
                return cr;
            }
            else
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 0;
                cr.responsemessage = "loginid is Invalid Or loginid Expire";
                return cr;
            }
        }

     
    }
}
