﻿using Amazon;
using Amazon.S3;
using Amazon.S3.Transfer;
using EduTech.CustomModels;
using EduTech.Data;
using EduTech.IServices;
using EduTech.Models;
using Grpc.Core;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EduTech.Services
{
    public class questionservices : Iquestionservices
    {
        private readonly ApplicationDbContext _Db;
        private readonly IAws3Services _aws3servies;
        private readonly string _bucketName;
        private readonly IAmazonS3 _awsS3Client;
        private readonly IAppConfiguration _appConfiguration;
        private readonly IHostingEnvironment _HostEnvironment;
        public questionservices(ApplicationDbContext Db, IAws3Services aws3services, IHostingEnvironment HostEnvironment, IAppConfiguration appConfiguration)
        {
            _Db = Db;
            _aws3servies = aws3services;
            _HostEnvironment = HostEnvironment;
            _HostEnvironment = HostEnvironment;
            _appConfiguration = appConfiguration;
            _bucketName = _appConfiguration.BucketName;
            _awsS3Client = new AmazonS3Client(_appConfiguration.AwsAccessKey, _appConfiguration.AwsSecretAccessKey, RegionEndpoint.GetBySystemName(_appConfiguration.Region));
        }
        private static TimeZoneInfo INDIAN_ZONE = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
        DateTime indianTime = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);
        string path = "";
        public async Task<Customresponse> Create(Customquestioncreate cc)
        {
            try
            {
                string webRootPath = _HostEnvironment.WebRootPath;
                string contentRootPath = _HostEnvironment.ContentRootPath;

                
                path = Path.Combine(webRootPath, "DisplayImages");
                if (cc.questionImages!=null && cc.questionImages.Count>0 && cc.excelAnswers != null && cc.excelAnswers.Count>0)
                {

                    List< question > questions = new List< question >(); 
                    if(cc.questionImages.Count==cc.excelAnswers.Count) 
                    {


                        for (int i = 0; i < cc.questionImages.Count; i++)
                        {
                            string img = cc.questionImages[i].ToString();
                            question aa = new question();

                            aa.id = Guid.NewGuid();
                            aa.isactive = true;
                            aa.isdelete = false;
                            aa.createdby = cc.authorid;
                            aa.createdon = indianTime;
                            aa.segmentid = cc.segmentid;
                            aa.Assessmentid = cc.Assessmentid;
                            aa.subjectid = cc.subjectid;
                            aa.topicid = cc.topicid;
                            aa.level = cc.level;
                            aa.gradeid = cc.gradeid;
                            aa.curriculumid = cc.curriculumid;

                            string base64 = img;
                            byte[] bytes = Convert.FromBase64String(base64.Split(',')[1]);
                            var filename = aa.id + ".jpg";

                            FileStream fs = new FileStream(path + "\\" + filename, FileMode.Create);
                            fs.Write(bytes, 0, bytes.Length);
                            IFormFile file = new FormFile(fs, 0, bytes.Length, filename, "https://s3edutech.s3.ap-south-1.amazonaws.com/" + filename);
                            fs.Close();

                            aa.questionname = "https://s3edutech.s3.ap-south-1.amazonaws.com/" + PostUploadedFile1(filename, file);
                            aa.questiondata = null;

                            aa.correctanswer = cc.correctanswer;
                            aa.questiontype = cc.questiontype;

                            questions.Add(aa);
                        }

                    if(questions.Count==cc.excelAnswers.Count)
                    {
                        for (int i = 0; i < questions.Count; i++)

                            questions[i].correctanswer = cc.excelAnswers[i].Answers;
                        
                        for (int i = 0; i < questions.Count; i++)
                            _Db.question.AddRange(questions[i]);

                        await _Db.SaveChangesAsync();
                            Customresponse cr = new Customresponse();
                        cr.responsecode = 1;
                        cr.responsemessage = "questions Created Successfully";
                        return cr;
                    }
                    else
                    {
                        Customresponse cr = new Customresponse(); ;
                        cr.responsecode = 0;
                        cr.responsemessage = "questions are not to equal answers";
                        return cr;
                    }
                    }
                    else
                    {
                        Customresponse cr = new Customresponse(); ;
                        cr.responsecode = 0;
                        cr.responsemessage = "questions are not to equal answers";
                        return cr;
                    }

                }
                else
                {
                    Customresponse cr = new Customresponse(); ;
                    cr.responsecode = 0;
                    cr.responsemessage = "Please enter the correct order";
                    return cr;
                }
            }
            catch(Exception ex)
            {
                throw;
            }
        }

        public string PostUploadedFile1(string fileName, IFormFile image)
        {
            try
            {
               
                TransferUtility transferUtility = new TransferUtility(_awsS3Client);
                TransferUtilityUploadRequest transferUtilityUploadRequest = new TransferUtilityUploadRequest();
                transferUtilityUploadRequest.Key = Path.GetFileName(fileName);
                transferUtilityUploadRequest.BucketName = _bucketName;
                transferUtilityUploadRequest.FilePath = path+"\\"+ fileName;
                transferUtilityUploadRequest.StorageClass = S3StorageClass.StandardInfrequentAccess;
                transferUtilityUploadRequest.CannedACL = S3CannedACL.PublicRead;
                transferUtilityUploadRequest.ContentType = "image/jpeg";

                transferUtility.Upload(transferUtilityUploadRequest);
                transferUtility.Dispose();

                return fileName;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public async Task<Customresponse> Delete(Customquestiondelete cc)
        {
            try
            {
                var Getid = _Db.question.Where(x => x.isdelete == false && x.isactive == true && x.id == cc.id).SingleOrDefault();
                if (Getid != null)
                {
                    Getid.isdelete = true;
                    _Db.Entry(Getid).State = (Microsoft.EntityFrameworkCore.EntityState.Modified);
                    await _Db.SaveChangesAsync();
                    Customresponse cr = new Customresponse(); ;
                    cr.responsecode = 1;
                    cr.responsemessage = "Deleted Successfully";
                    return cr;
                }
                else
                {
                    Customresponse cr = new Customresponse(); ;
                    cr.responsecode = 2;
                    cr.responsemessage = "id is incorrect";
                    return cr;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Customresponse> Edit(Customquestionedit cc)
        {
            try
            {
                if (cc.Bulkimage != null)
                {
                    question aa = _Db.question.Where(x => x.isdelete == false && x.isactive == true && x.id == cc.id).SingleOrDefault();
                    if (aa != null)
                    {

                        aa.segmentid = cc.segmentid;
                        aa.Assessmentid = cc.Assessmentid;
                        aa.subjectid = cc.subjectid;
                        aa.topicid = cc.topicid;
                        aa.level = cc.level;
                        aa.gradeid = cc.gradeid;
                        aa.curriculumid = cc.curriculumid;
                        string imagename = _aws3servies.PostUploadedFile(cc.Bulkimage);
                        aa.questionname = imagename;
                        aa.correctanswer = cc.correctanswer;
                        aa.questiontype = cc.questiontype;
                        _Db.Entry(aa).State = (Microsoft.EntityFrameworkCore.EntityState.Modified);
                        await _Db.SaveChangesAsync();
                        Customresponse cr = new Customresponse(); ;
                        cr.responsecode = 1;
                        cr.responsemessage = "questions Edited Successfully";
                        return cr;
                    }
                    else
                    {
                        Customresponse cr = new Customresponse(); ;
                        cr.responsecode = 0;
                        cr.responsemessage = "id is incorrect";
                        return cr;
                    }

                }
                else
                {
                    question aa = new question();
                    aa.id = Guid.NewGuid();
                    aa.isactive = true;
                    aa.isdelete = false;
                    aa.createdby = cc.authorid;
                    aa.createdon = indianTime;
                    aa.segmentid = cc.segmentid;
                    aa.Assessmentid = cc.Assessmentid;
                    aa.subjectid = cc.subjectid;
                    aa.topicid = cc.topicid;
                    aa.level = cc.level;
                    aa.gradeid = cc.gradeid;
                    aa.curriculumid = cc.curriculumid;
                    aa.questionname = cc.questionname;
                    aa.correctanswer = cc.correctanswer;
                    aa.questiontype = cc.questiontype;
                    _Db.Entry(aa).State = (Microsoft.EntityFrameworkCore.EntityState.Modified);
                    await _Db.SaveChangesAsync();
                    Customresponse cr = new Customresponse(); ;
                    cr.responsecode = 1;
                    cr.responsemessage = "questions Created Successfully";
                    return cr;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<IEnumerable<question>> GetAllquestion()
        {
            try
            {
                return await _Db.question.Where(x => x.isdelete == false && x.isactive == true).ToListAsync();
                //return await _Db.question.Join(_Db.question_type, x => x.questiontype, y => y.id, (x, y) => x)
                //    .Join(_Db.subject,s=>s.subjectid,d=>d.id,(s,d)=>s)
                //    .Join(_Db.topic,c=>c.topicid,v=>v.id,(c,v)=>c) .ToListAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<question> Getquestionbyid(string id)
        {
            try
            {
                return await _Db.question.Where(x => x.isdelete == false && x.isactive == true && x.id == new Guid(id)).SingleOrDefaultAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
