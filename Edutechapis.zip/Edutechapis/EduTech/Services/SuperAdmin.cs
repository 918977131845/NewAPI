﻿using EduTech.CustomModels;
using EduTech.Data;
using EduTech.IServices;
using EduTech.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.Services
{
    public class SuperAdmin : ISuperAdmin
    {

        private readonly ApplicationDbContext _Db;
        private readonly IAws3Services _aws3servies;
        private readonly ISentEmailSms _sentEmailSms;



        public SuperAdmin(ApplicationDbContext Db, IAws3Services aws3services, ISentEmailSms sentEmailSms)
        {
            _Db = Db;
            _aws3servies = aws3services;
            _sentEmailSms = sentEmailSms;

        }

        // ========================================================= SuperAdmin Create =====================================================

        public async Task<Customresponse> Superadmincreate(Customsuperadmincreate cc)
        {
            try
            {
                var Getdata = _Db.superadmin.Where(x => x.isdeleted == false && x.isactive == true).Count();   // To Allow one SuperAdmin
                if (Getdata < 1)
                {
                    superadmin aa = new superadmin();   // Calling Model To Create Superadmin
                    aa.id = Guid.NewGuid();
                    aa.Name = cc.Name;
                    aa.password = cc.password;
                    aa.isactive = true;
                    aa.isdeleted = false;
                    aa.createdby = aa.id;
                    aa.createdon = System.DateTimeOffset.Now;
                    aa.updatedby = aa.id;
                    aa.updatedon = System.DateTimeOffset.Now;
                    aa.email = cc.email;
                    aa.phone = cc.phone;
                    if (cc.image != null)
                    {

                        string uniqueFileName = _aws3servies.PostUploadedFile(cc.image);  // Calling uploadfile to upload images
                        aa.image = "https://s3edutech.s3.ap-south-1.amazonaws.com/" + uniqueFileName + "";
                    }
                    await _Db.superadmin.AddAsync(aa);  // Add CustomSuperAdmin Details To  SuperAdmin Table
                    _Db.SaveChanges(); // Saving Database
                    _sentEmailSms.SuperadminSentEmailSms(aa.Name, aa.email, aa.password, aa.phone);
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 1;
                    cr.responsemessage = "Created Successfully";
                    return cr;
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "Superadmin Already Created Successfully";
                    return cr;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        // ========================================================= SuperAdmin Delete ======================================================

        public async void SuperadminDelete(string id, string authorid)
        {
            try
            {
                var Getdata = _Db.superadmin.Where(x => x.isdeleted == false && x.isactive == true && x.id == new Guid(id)).SingleOrDefault();
                if (Getdata != null)
                {
                    Getdata.isdeleted = true;
                    Getdata.updatedby = new Guid(authorid);
                    Getdata.updatedon = System.DateTimeOffset.Now;

                    _Db.Entry(Getdata).State = (Microsoft.EntityFrameworkCore.EntityState.Modified);
                    await _Db.SaveChangesAsync();
                }

            }
            catch (Exception)
            {
                throw;
            }

        }

        // ========================================================= SuperAdmin Post(Edit) ===================================================

        public async Task<Customresponse> SuperadminEdit(Customsuperadminedit cc)
        {
            try
            {

                var Getdata = _Db.superadmin.Where(x => x.isdeleted == false && x.isactive == true && x.id == cc.id).SingleOrDefault();
                if (Getdata != null)
                {
                    Getdata.Name = cc.Name;
                    Getdata.email = cc.email;
                    Getdata.phone = cc.phone;
                    Getdata.updatedby = Getdata.id;
                    Getdata.updatedon = System.DateTimeOffset.Now;
                    if (cc.image != null)
                    {
                        string uniqueFileName = _aws3servies.PostUploadedFile(cc.image);
                        Getdata.image = "https://s3edutech.s3.ap-south-1.amazonaws.com/" + uniqueFileName + "";
                    }
                    _Db.Entry(Getdata).State = (Microsoft.EntityFrameworkCore.EntityState.Modified);
                    await _Db.SaveChangesAsync();
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 1;
                    cr.responsemessage = "Updated Successfully";
                    return cr;
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "id does not exist";
                    return cr;
                }

            }
            catch (Exception)
            {
                throw;
            }
        }

        // ========================================================= SuperAdmin GetAll ========================================================

        public async Task<IEnumerable<superadmin>> SuperAdminGetAll()
        {
            try
            {
                var Getdata = await _Db.superadmin.Where(x => x.isdeleted == false && x.isactive == true).ToListAsync();
                return Getdata;
            }
            catch (Exception)
            {
                throw;
            }

        }

        // ========================================================= SuperAdmin Get By authorid ===============================================

        public async Task<IEnumerable<superadmin>> SuperAdminGetByauthor(string authorid)
        {
            try
            {
                var Getdata = await _Db.superadmin.Where(x => x.isdeleted == false && x.isactive == true && x.createdby == new Guid(authorid)).ToListAsync();
                return Getdata;
            }
            catch (Exception)
            {
                throw;
            }

        }

        // ========================================================= Superadmin Get(Edit) By Id ===============================================

        public async Task<superadmin> SuperAdminGetbyId(string authorid)
        {
            try
            {
                var getdata = await _Db.superadmin.Where(x => x.isdeleted == false && x.isactive == true && x.id == new Guid(authorid)).SingleOrDefaultAsync();
                return getdata;
            }
            catch (Exception)
            {
                throw;
            }
        }

        // ========================================================= Superadmin resetpassword =================================================
        public async Task<Customresponse> postresetpassword(Customresetpassword cc)
        {
            try
            {
                if(cc.currentpassword== _Db.superadmin.Where(x => x.isdeleted == false && x.isactive == true && x.id == cc.authorid).Select(p=>p.password).SingleOrDefault())
                {
                    if (cc.newpassword == cc.confirmpassword)
                    {
                        var getdata = _Db.superadmin.Where(x => x.isdeleted == false && x.isactive == true && x.id == cc.authorid).SingleOrDefault();
                        if (getdata != null)
                        {
                            getdata.password = cc.confirmpassword;
                            getdata.updatedby = cc.authorid;
                            getdata.updatedon = System.DateTime.Now;
                            _Db.Entry(getdata).State = EntityState.Modified;
                            await _Db.SaveChangesAsync();
                            Customresponse cr = new Customresponse();
                            cr.responsecode = 1;
                            cr.responsemessage = "Password Successfully Updated";
                            return cr;
                        }
                        else
                        {
                            Customresponse cr = new Customresponse();
                            cr.responsecode = 2;
                            cr.responsemessage = "authorid cann't be null";
                            return cr;
                        }
                    }
                    else
                    {
                        Customresponse cr = new Customresponse();
                        cr.responsecode = 2;
                        cr.responsemessage = "newpassword and confirmpassword does n't match";
                        return cr;
                    }
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "Please enter the correct current password";
                    return cr;
                }

            }
            catch (Exception)
            {
                throw;
            }
        }

        // ========================================================= Superadmin forgetpassword =================================================
        public async Task<Customresponse> PostForgetpassword(Customforgetpassword cc)
        {
            try
            {
                var Getdata = _Db.superadmin.Where(x => x.isdeleted == false && x.isactive == true && x.email == cc.email).SingleOrDefault();
                if (Getdata != null)
                {
                    var otp = _sentEmailSms.forgetpasswordotp(Getdata.Name, Getdata.email, Getdata.phone);
                    Getdata.otp = otp;
                    _Db.Entry(Getdata).State = EntityState.Modified;
                    await _Db.SaveChangesAsync();
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 1;
                    cr.responsemessage = "Otp Successfully Sent";
                    cr.authorid = Getdata.id;
                    return cr;
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "emailid invalid";
                    return cr;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
