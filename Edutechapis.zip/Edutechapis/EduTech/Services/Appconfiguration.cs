﻿using EduTech.IServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.Services
{
	public class AppConfiguration : IAppConfiguration
	{
		// Keep the following details in appsettings.config file or DB or Enivironment variable
		// Get those values from it and assign to the below varibales. Based on the approach , modify the below code.
		public AppConfiguration()
		{
			BucketName = "s3edutech";
			Region = "ap-south-1";
			AwsAccessKey = "AKIA23BILI34QODDVBNN";
			AwsSecretAccessKey = "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";
			
		}

		public string BucketName { get; set; }
		public string Region { get; set; }
		public string AwsAccessKey { get; set; }
		public string AwsSecretAccessKey { get; set; }
		}
}
