﻿using EduTech.IServices;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace EduTech.Services
{
    public class Jwttokenmanager : IJwttokenmanager
    {
        private readonly IConfiguration _configuration;
        public Jwttokenmanager(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public string Authenticate(string id)
        {
            var key = _configuration.GetValue<string>("JwtConfig:Key");
            var keybytes = Encoding.ASCII.GetBytes(key);

            var tokenHandler = new JwtSecurityTokenHandler();

            var tokenDescriptor = new SecurityTokenDescriptor()
            {
                Subject = new ClaimsIdentity(
                       new Claim[]
                       {
                        new Claim(ClaimTypes.NameIdentifier, id)
                       }),
                Expires = DateTime.UtcNow.AddDays(1),
                SigningCredentials = new SigningCredentials(
                    new SymmetricSecurityKey(keybytes), SecurityAlgorithms.HmacSha256Signature)
            };
            //4. Create Token
            var token = tokenHandler.CreateToken(tokenDescriptor);

            // 5. Return Token from method
            return tokenHandler.WriteToken(token);

        }
    }
}
