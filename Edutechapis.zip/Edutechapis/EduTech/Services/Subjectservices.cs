﻿using EduTech.CustomModels;
using EduTech.Data;
using EduTech.IServices;
using EduTech.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.Services
{
    public class Subjectservices : ISubjectservices
    {
        private readonly ApplicationDbContext _Db;
        private readonly IAws3Services _aws3servies;
        public Subjectservices(ApplicationDbContext Db, IAws3Services aws3services)
        {
            _Db = Db;
            _aws3servies = aws3services;
        }
        private static TimeZoneInfo INDIAN_ZONE = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
        DateTime indianTime = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);

        public async Task<IEnumerable<subject>> GetAllsubject()
        {
            try
            {
                return await _Db.subject.Where(x => x.isdelete == false && x.isactive == true).ToListAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<subject> GetIdsubject(Guid id)
        {

            try
            {
                return await _Db.subject.Where(x => x.isdelete == false && x.isactive == true && x.id == id).SingleOrDefaultAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<IEnumerable<subject>> Getsubjectbyadminid(Guid authorid)
        {
            try
            {
                return await _Db.subject.Where(x => x.isdelete == false && x.isactive == true && x.adminid == authorid).ToListAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<IEnumerable<subject>> GetsubjectByauthorid(string authorid)
        {
            try
            {
                return await _Db.subject.Where(x => x.isdelete == false && x.isactive == true && x.createdby == new Guid(authorid)).ToListAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Customresponse> PostCreate(Customsubject cc)
        {
            try
            {
                subject gg = new subject();
                gg.id = Guid.NewGuid();
                gg.createdby = cc.authorid;
                gg.createdon = indianTime;
                gg.updatedby = cc.authorid;
                gg.updatedon = indianTime;
                gg.isactive = true;
                gg.isdelete = false;
                var Getadmin = _Db.admin.Where(x => x.isdeleted == false && x.isactive == true && x.id == cc.authorid).SingleOrDefault();
                var Getteacher = _Db.teacher.Where(x => x.isdeleted == false && x.isactive == true && x.id == cc.authorid).SingleOrDefault();
                if (Getadmin != null)
                {
                    gg.adminid = Getadmin.id;
                }
                else
                {
                    gg.adminid = Getteacher.createdby;
                }
                gg.title = cc.title;
               
                gg.segmentid = cc.segmentid;
                gg.gradeid = cc.gradeid;
                gg.carriculum = cc.carriculum;
                
                _Db.subject.Add(gg);
                await _Db.SaveChangesAsync();
                Customresponse cr = new Customresponse();
                cr.responsecode = 1;
                cr.responsemessage = "Created Successfully";
                return cr;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Customresponse> PostDelete(CustomsubjectDelete cc)
        {
            try
            {
                var gg = _Db.subject.Where(x => x.isdelete == false && x.isactive == true && x.id == cc.id).SingleOrDefault();
                if (gg != null)
                {
                    gg.isdelete = true;
                    gg.updatedby = cc.authorid;
                    gg.updatedon = indianTime;
                    _Db.Entry(gg).State = (Microsoft.EntityFrameworkCore.EntityState.Modified);
                    await _Db.SaveChangesAsync();
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 1;
                    cr.responsemessage = "Deleted Successfully";
                    return cr;
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "id is incorrect";
                    return cr;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Customresponse> PostEdit(CustomsubjectEdit cc)
        {
            try
            {
                var gg = _Db.subject.Where(x => x.isdelete == false && x.isactive == true && x.id == cc.id).SingleOrDefault();
                if (gg != null)
                {
                    gg.updatedby = cc.authorid;
                    gg.updatedon = indianTime;
                  
                    gg.segmentid = cc.segmentid;
                    gg.gradeid = cc.gradeid;
                    gg.carriculum = cc.carriculum;
                    gg.title = cc.title;
                    _Db.Entry(gg).State = (Microsoft.EntityFrameworkCore.EntityState.Modified);
                    await _Db.SaveChangesAsync();
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 1;
                    cr.responsemessage = "Deleted Successfully";
                    return cr;

                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "id is incorrect";
                    return cr;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
