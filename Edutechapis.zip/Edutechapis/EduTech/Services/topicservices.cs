﻿using EduTech.CustomModels;
using EduTech.Data;
using EduTech.IServices;
using EduTech.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.Services
{
    public class topicservices : Itopicservices
    {
        private static TimeZoneInfo INDIAN_ZONE = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
        DateTime indianTime = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);

        private readonly ApplicationDbContext _Db;
        private readonly IAws3Services _aws3servies;
        public topicservices(ApplicationDbContext Db, IAws3Services aws3services)
        {
            _Db = Db;
            _aws3servies = aws3services;
        }
        public async Task<Customresponse> Create(Customtopic cc)
        {
            try
            {
                topic cs = new topic();
                cs.id = Guid.NewGuid();
                cs.isactive = true;
                cs.isdelete = false;
                cs.createdby = cc.authorid;
                cs.createdon = indianTime;
                cs.modifiedby = cc.authorid;
                cs.modifiedon = indianTime;
                cs.segmentid = cc.segmentid;
                cs.gradeid = cc.gradeid;
                cs.curriculumid = cc.curriculumid;
                cs.subjectid = cc.subjectid;
                cs.assessmenttypeid = cc.assessmenttypeid;
                cs.topic_name = cc.topic_name;
                _Db.topic.Add(cs);
                await _Db.SaveChangesAsync();
                Customresponse cr = new Customresponse();
                cr.responsecode = 1;
                cr.responsemessage = "Created Successfully";
                return cr;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Customresponse> Delete(CustomtopicDelete cc)
        {
            try
            {
                var Getid = _Db.topic.Where(x => x.isdelete == false && x.isactive == true && x.id == cc.id).SingleOrDefault();
                if (Getid != null)
                {
                    Getid.isdelete = true;
                    Getid.modifiedby = cc.authorid;
                    Getid.modifiedon = indianTime;
                    _Db.Entry(Getid).State = (Microsoft.EntityFrameworkCore.EntityState.Modified);
                    await _Db.SaveChangesAsync();
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 1;
                    cr.responsemessage = "Deleted Successfully";
                    return cr;
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "id is incorrect";
                    return cr;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Customresponse> Edit(Customtopicedit cc)
        {
            try
            {
                var Getid = _Db.topic.Where(x => x.isdelete == false && x.isactive == true && x.id == cc.id).SingleOrDefault();
                if (Getid != null)
                {
                    Getid.topic_name = cc.topic_name;
                    Getid.segmentid = cc.segmentid;
                    Getid.assessmenttypeid = cc.assessmenttypeid;
                    Getid.curriculumid = cc.curriculumid;
                    Getid.subjectid = cc.subjectid;
                    Getid.gradeid = cc.gradeid;
                    Getid.modifiedby = cc.authorid;
                    Getid.modifiedon = indianTime;
                    _Db.Entry(Getid).State = (Microsoft.EntityFrameworkCore.EntityState.Modified);
                    await _Db.SaveChangesAsync();
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 1;
                    cr.responsemessage = "Updated Successfully";
                    return cr;
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "id is incorrect";
                    return cr;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<IEnumerable<topic>> Getalltopic()
        {
            try
            {
                return await _Db.topic.Where(x => x.isdelete == false && x.isactive == true).ToListAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<topic> Gettopicbyid(string id)
        {
            try
            {
                return await _Db.topic.Where(x => x.isdelete == false && x.id == new Guid(id) && x.isactive == true).SingleOrDefaultAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
