﻿using EduTech.CustomModels;
using EduTech.Data;
using EduTech.IServices;
using EduTech.Models;
using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.Services
{
    public class TeacherServices: ITeacherServices
    {
        private readonly ApplicationDbContext _Db;
        private readonly ISentEmailSms _sentEmailSms;
        public TeacherServices(ApplicationDbContext Db,ISentEmailSms sentEmailSms)
        {
            _Db = Db;
            _sentEmailSms = sentEmailSms;
        }

        // =============================================== Teacher Create ======================================================

        public async Task<Customresponse> TeacherCreate(Customteachercreate cc)
        {
            try
            {
                var Getemail = _Db.teacher.Where(x => x.isdeleted == false && x.isactive == true && x.email == cc.email).SingleOrDefault();
                if (Getemail == null)
                {
                    var Getphone = _Db.teacher.Where(x => x.isdeleted == false && x.isactive == true && x.mobilenumber == cc.mobilenumber).SingleOrDefault();
                    if (Getphone == null)
                    { 

                        teacher ca = new teacher();
                        ca.id = Guid.NewGuid();
                        ca.isdeleted = false;
                        ca.isactive = true;
                        ca.createdby = cc.authorid;
                        ca.createdon = System.DateTimeOffset.Now;
                        ca.updatedby = cc.authorid;
                        ca.updatedon = System.DateTimeOffset.Now;
                        ca.name = cc.name;
                        ca.email = cc.email;
                        ca.mobilenumber = cc.mobilenumber;
                        Random rr = new Random();
                        ca.password = Convert.ToString(rr.Next(1, 1000000));
                        var allChar = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
                        var random = new Random();
                        var resultToken = new string(
                           Enumerable.Repeat(allChar, 8)
                           .Select(token => token[random.Next(token.Length)]).ToArray());

                        string authToken = resultToken.ToString();
                        ca.token = authToken;
                        ca.course = cc.course;
                        ca.DateOfBirth = cc.DateOfBirth;
                        ca.Address = cc.Address;
                       // ca.subject = cc.subject;
                        await _Db.teacher.AddAsync(ca);
                        _Db.SaveChanges();
                        _sentEmailSms.SendEmailTecherORStudent(ca.name, ca.email, ca.token);
                        Customresponse cr = new Customresponse();
                        cr.responsecode = 1;
                        cr.responsemessage = "Created Successfully";
                        return cr;
                    }
                    else
                    {
                        Customresponse cr = new Customresponse();
                        cr.responsecode = 2;
                        cr.responsemessage = "Phone Already Use";
                        return cr;
                    }
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "Email Already Use";
                    return cr;
                }
            }
            catch(Exception)
            {
                throw;
            }
           
          
        }

        // ============================================== Teacher Delete ========================================================

        public async Task<Customresponse> TeacherDelete(Guid id,Guid authorid)
        {
            try
            {
                var Getdata = _Db.teacher.Where(x => x.isdeleted == false && x.isactive == true && x.id == id).SingleOrDefault();
                if (Getdata != null)
                {
                    Getdata.updatedby = authorid;
                    Getdata.updatedon = System.DateTimeOffset.Now;
                    Getdata.isdeleted = true;
                    _Db.Entry(Getdata).State = (Microsoft.EntityFrameworkCore.EntityState.Modified);
                    await _Db.SaveChangesAsync();
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 1;
                    cr.responsemessage = "Deleted Successfully";
                    return cr;
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "Invalid id";
                    return cr;
                }
            }
            catch (Exception)
            {
                throw;
            }
           
           
        }

        // ============================================== Teacher Edit(Post) =======================================================

        public async Task<Customresponse> TeacherEdit(Customteacher cc)
        {
            try
            {
                var Getemail = _Db.teacher.Where(x => x.isdeleted == false && x.isactive == true && x.id != cc.id && x.email == cc.email).SingleOrDefault();
                if (Getemail == null)
                {
                    var Getphone = _Db.teacher.Where(x => x.isdeleted == false && x.isactive == true && x.id != cc.id && x.mobilenumber == cc.mobilenumber).SingleOrDefault();
                    if (Getphone == null)
                    {
                        var Getdata = _Db.teacher.Where(x => x.isdeleted == false && x.isactive == true && x.id == cc.id).SingleOrDefault();
                        if (Getdata != null)
                        {
                            Getdata.updatedby = cc.authorid;
                            Getdata.updatedon = System.DateTimeOffset.Now;
                            Getdata.subject = cc.subject;
                            Getdata.course = cc.course;
                            Getdata.name = cc.name;
                            Getdata.email = cc.email;
                            Getdata.mobilenumber = cc.mobilenumber;
                            _Db.Entry(Getdata).State = (Microsoft.EntityFrameworkCore.EntityState.Modified);
                            await _Db.SaveChangesAsync();
                            Customresponse cr = new Customresponse();
                            cr.responsecode = 1;
                            cr.responsemessage = "Updated Successfully";
                            return cr;
                        }
                        else
                        {
                            Customresponse cr = new Customresponse();
                            cr.responsecode = 2;
                            cr.responsemessage = "id is invalid";
                            return cr;
                        }
                    }
                    else
                    {

                        Customresponse cr = new Customresponse();
                        cr.responsecode = 2;
                        cr.responsemessage = "Phone Already in Use";
                        return cr;
                    }
                }
                else
                {

                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "Email Already in Use";
                    return cr;
                }
                
            }
            catch (Exception)
            {
                throw;
            }
           
           
        }

        // ============================================ Teacher Table All Data ====================================================

        public async Task<IEnumerable<teacher>> TeacherGetAll()
        {
            try
            {
                return await _Db.teacher.Where(x => x.isdeleted == false && x.isactive == true).ToListAsync();
            }
            catch (Exception)
            {
                throw;
            }
            
        }

        // ============================================ Teacher  Getdata by authorid ==============================================

        public async Task<IEnumerable<teacher>> TeacherGetByauthor(string authorid)
        {
            try
            {
                return await _Db.teacher.Where(x => x.isdeleted == false && x.isactive == true && x.createdby == new Guid(authorid)).ToListAsync();
            }
            catch (Exception)
            {
                throw;
            }
            
        }

        // ============================================ Teacher (Edit)Get data by id =================================================

        public async Task<teacher> TeacherGetbyId(string id)
        {
            try
            {
                return await _Db.teacher.Where(x => x.isdeleted == false && x.isactive == true && x.id == new Guid(id)).SingleOrDefaultAsync();
            }
            catch (Exception)
            {
                throw;
            }
          
        }

        // ========================================================= Teacher resetpassword =================================================

        public async Task<Customresponse> postresetpassword(Customresetpassword cc)
        {
            try
            {
                if(cc.currentpassword== _Db.teacher.Where(x => x.isdeleted == false && x.isactive == true && x.id == cc.authorid).Select(p=>p.password).SingleOrDefault())
                {
                    if (cc.newpassword == cc.confirmpassword)
                    {
                        var getdata = _Db.teacher.Where(x => x.isdeleted == false && x.isactive == true && x.id == cc.authorid).SingleOrDefault();
                        if (getdata != null)
                        {
                            getdata.password = cc.confirmpassword;
                            getdata.updatedby = cc.authorid;
                            getdata.updatedon = System.DateTime.Now;
                            _Db.Entry(getdata).State = EntityState.Modified;
                            await _Db.SaveChangesAsync();
                            Customresponse cr = new Customresponse();
                            cr.responsecode = 1;
                            cr.responsemessage = "Password Successfully Updated";
                            return cr;
                        }
                        else
                        {
                            Customresponse cr = new Customresponse();
                            cr.responsecode = 2;
                            cr.responsemessage = "authorid cann't be null";
                            return cr;
                        }
                    }
                    else
                    {
                        Customresponse cr = new Customresponse();
                        cr.responsecode = 2;
                        cr.responsemessage = "newpassword and confirmpassword does n't match";
                        return cr;
                    }
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "Please enter the correct current password";
                    return cr;
                }

            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Customresponse> postchangepassword(CustomChangePassword cc)
        {
            try
            {

                if (cc.newpassword == cc.confirmpassword)
                {
                    var getdata = _Db.teacher.Where(x => x.isdeleted == false && x.isactive == true && x.id == cc.authorid).SingleOrDefault();
                    if (getdata != null)
                    {
                        getdata.password = cc.confirmpassword;
                        getdata.updatedby = cc.authorid;
                        getdata.updatedon = System.DateTime.Now;
                        _Db.Entry(getdata).State = EntityState.Modified;
                        await _Db.SaveChangesAsync();
                        Customresponse cr = new Customresponse();
                        cr.responsecode = 1;
                        cr.responsemessage = "Password Successfully Updated";
                        return cr;
                    }
                    else
                    {
                        Customresponse cr = new Customresponse();
                        cr.responsecode = 2;
                        cr.responsemessage = "authorid cann't be null";
                        return cr;
                    }
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "newpassword and confirmpassword doesn't match";
                    return cr;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        // ========================================================= teacher forgetpassword =================================================
        public async Task<Customresponse> PostForgetpassword(string email)
        {
            try
            {
                var Getdata = _Db.teacher.Where(x => x.isdeleted == false && x.isactive == true && x.email == email).SingleOrDefault();
                if (Getdata != null)
                {
                    var otp = _sentEmailSms.forgetpasswordotp(Getdata.name, Getdata.email, Getdata.mobilenumber);
                    Getdata.otp = otp;
                    _Db.Entry(Getdata).State = EntityState.Modified;
                    await _Db.SaveChangesAsync();
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 1;
                    cr.responsemessage = "Otp Successfully Sent";
                    cr.authorid = Getdata.id;
                    return cr;
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "emailid invalid";
                    return cr;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
