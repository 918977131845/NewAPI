﻿using EduTech.CustomModels;
using EduTech.Data;
using EduTech.IServices;
using EduTech.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.Services
{
    public class Assessment_typeservices : IAssessment_typeservices
    {
        private static TimeZoneInfo INDIAN_ZONE = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
        DateTime indianTime = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, INDIAN_ZONE);

        private readonly ApplicationDbContext _Db;
        private readonly IAws3Services _aws3servies;
        public Assessment_typeservices(ApplicationDbContext Db, IAws3Services aws3services)
        {
            _Db = Db;
            _aws3servies = aws3services;
        }

        public async Task<IEnumerable<Assessment_type>> GetAssessment_Type()
        {
            try
            {
                return await _Db.Assessment_type.Where(x => x.isdelete == false && x.isactive == true).ToListAsync();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Customresponse> Create(Customassessmenttype model)
        {
            var Validadmin = _Db.admin.Where(x => x.id == model.id && x.isactive == true &&
                                               x.isdeleted == false).SingleOrDefault();
            try
            {
                if (Validadmin != null)
                {
                    Assessment_type Ass_Type = new Assessment_type();
                    Ass_Type.adminid = model.adminid;
                    Ass_Type.id = Guid.NewGuid();
                    Ass_Type.isactive = true;
                    Ass_Type.Assessmenttype_name = model.Assessmenttype_name;
                    Ass_Type.segmentid = model.segmentid;
                    Ass_Type.createdby = model.createdby;
                    Ass_Type.createdon = indianTime;
                    Ass_Type.Discount = model.Discount;
                    Ass_Type.isdelete = false;
                    Ass_Type.TopicWiseTest = model.TopicWiseTest;
                    Ass_Type.Duration = model.Duration;
                    Ass_Type.Eachquestion_correctmarks = model.Eachquestion_correctmarks;
                    Ass_Type.Eachquestion_negativemarking = model.Eachquestion_negativemarking;
                    Ass_Type.gradeid = model.gradeid;
                    Ass_Type.instructions = model.instructions;
                    Ass_Type.MockTest = model.MockTest;
                    Ass_Type.SubjectTest = model.SubjectTest;
                    Ass_Type.Price = model.Price;
                    Ass_Type.PackageDuration = model.PackageDuration;
                    Ass_Type.Totalmarks = model.Totalmarks;
                    Ass_Type.TotalQuestions = model.TotalQuestions;

                    _Db.Assessment_type.Add(Ass_Type);
                    await _Db.SaveChangesAsync();
                    Customresponse ce = new Customresponse();
                    ce.responsecode = 1;
                    ce.responsemessage = "Data inserted Successfully";
                    return ce;
                }
                else
                {
                    Customresponse ce = new Customresponse();
                    ce.responsecode = 0;
                    ce.responsemessage = "Not a valid Admin";
                    return ce;

                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
