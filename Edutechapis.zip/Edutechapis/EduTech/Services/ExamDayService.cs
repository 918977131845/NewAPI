﻿using EduTech.CustomModels;
using EduTech.Data;
using EduTech.IServices;
using EduTech.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace EduTech.Services
{
    public class ExamDayService : IExamDay
    {

        private readonly ApplicationDbContext _Db;
        public ExamDayService(ApplicationDbContext Db)
        {
            _Db = Db;
        }
        public async Task<Customresponse> StudentExamDayCreate(CustomExamDay model)
        {
            try
            {
                var ValidStudent = _Db.students.Where(x => x.id == model.id && x.isactive==true && 
                                                x.isdeleted==false && x.email==model.emailid).SingleOrDefault();
                if(ValidStudent!=null)
                {
                    var Result = _Db.question.Where(x => x.Assessmentid == model.Assessmentid)
                           .OrderBy(result => EF.Functions.Random())
                           .Take(90).AsEnumerable().ToList();

                    if (Result != null && Result.Count() == 90)
                    {
                        List<ExamDay> examDays = new List<ExamDay>();


                        for (int i = 0; i < Result.Count(); i++)
                        {
                            ExamDay examDay = new ExamDay();
                            examDay.id = Guid.NewGuid();
                            examDay.segmentid = Result[i].segmentid;
                            examDay.topicid = Result[i].topicid;
                            examDay.correctanswer = Result[i].correctanswer;
                            examDay.subjectid = Result[i].subjectid;
                            examDay.gradeid = Result[i].gradeid;
                            examDay.CreatedDate = DateTime.Now;
                            examDay.studentanswer = String.Empty;
                            examDay.curriculumid = Result[i].curriculumid;

                            examDay.Approvedbystudent = model.id;

                            examDay.Assessmentid = model.Assessmentid;
                            examDay.questiondata = Result[i].questiondata;
                            examDay.questionname = Result[i].questionname;
                            examDay.questiontype = Result[i].questiontype;
                            examDays.Add(examDay);
                        }
                        for (int i = 0; i < examDays.Count; i++)
                            _Db.examDays.AddRange(examDays[i]);

                        await _Db.SaveChangesAsync();
                        Customresponse ce = new Customresponse();
                        ce.responsecode = 1;
                        ce.responsemessage = "questions inserted Successfully";
                        return ce;
                    }
                    else
                    {
                        Customresponse ce = new Customresponse();
                        ce.responsecode = 0;
                        ce.responsemessage = "questions are not picked at count 90";
                        return ce;
                    }
                }
                else
                {
                    Customresponse ce = new Customresponse();
                    ce.responsecode = 0;
                    ce.responsemessage = "Not a Valid Student";
                    return ce;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
