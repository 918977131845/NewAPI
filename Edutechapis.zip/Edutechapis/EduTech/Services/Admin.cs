﻿using EduTech.CustomModels;
using EduTech.Data;
using EduTech.IServices;
using EduTech.Models;
using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.Services
{
    public class Admin : IAdmin
    {
        private readonly ApplicationDbContext _Db;
        private readonly ISentEmailSms _sentEmailSms;
        private readonly IAws3Services _aws3servies;
        public Admin(ApplicationDbContext Db, IAws3Services aws3services,ISentEmailSms sentEmailSms)
        {
            _Db = Db;
            _aws3servies = aws3services;
            _sentEmailSms = sentEmailSms;
        }

        // ================================================================ Admin Create =================================================================
        public async Task<Customresponse> Admincreate(CustomadminCreate model)
        {
            try
            {
                var Getdata = _Db.admin.Where(x => x.isdeleted == false && x.isactive == true && x.email == model.email).SingleOrDefault();
                if (Getdata == null)
                {
                    var Getphone = _Db.admin.Where(x => x.isdeleted == false && x.isactive == true && x.phone == model.phone).SingleOrDefault();
                    if (Getphone == null)
                    {
                        admin aa = new admin();
                        aa.id = Guid.NewGuid();
                        aa.isactive = true;
                        aa.isdeleted = false;
                        aa.areacode = model.areacode;
                        aa.address = model.address;
                        Random rr = new Random();
                        aa.password = Convert.ToString(rr.Next(1,1000000));
                        aa.area = model.area;
                        aa.email = model.email;
                        aa.phone = model.phone;
                        aa.Name = model.Name;
                        aa.organizationname = model.organizationname;
                        aa.organizationinfomail = model.organizationinfomail;
                        aa.organizationinfomailpassword = model.organizationinfomailpassword;
                        aa.createdon = System.DateTimeOffset.Now;
                        aa.updatedon = System.DateTimeOffset.Now;
                        aa.createdby = aa.id;
                        aa.updatedby = aa.id;




                        var allChar = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
                        var random = new Random();
                        var resultToken = new string(
                           Enumerable.Repeat(allChar, 8)
                           .Select(token => token[random.Next(token.Length)]).ToArray());

                        string authToken = resultToken.ToString();
                        aa.token = authToken;





                        if (model.image != null)
                        {
                            string uniqueFileName = _aws3servies.PostUploadedFile(model.image);
                            aa.image = "https://s3edutech.s3.ap-south-1.amazonaws.com/" + uniqueFileName + "";
                        }

                        _Db.admin.Add(aa);
                        await _Db.SaveChangesAsync();
                        //_sentEmailSms.SuperadminSentEmailSms(aa.Name, aa.email, aa.password, aa.phone);
                        _sentEmailSms.SendEmailTecherORStudent(aa.Name, aa.email, aa.token);
                        Customresponse cr = new Customresponse();
                        cr.responsecode = 1;
                        cr.responsemessage = "Created Successfully";
                        return cr;
                    }
                    else
                    {
                        Customresponse cr = new Customresponse();
                        cr.responsecode = 2;
                        cr.responsemessage = "phone number already exists";
                        return cr;
                    }
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "email already exists";
                    return cr;
                }

            }
            catch (Exception)
            {
                throw;
            }
        }

        // ================================================================ Admin Delete =================================================================
        public async Task<Customresponse> AdminDelete(Guid id, Guid authorid)
        {
            try
            {
                var Getdata = _Db.admin.Where(x => x.isdeleted == false && x.isactive == true && x.id == id).SingleOrDefault();
                if (Getdata != null)
                {
                    Getdata.updatedby = authorid;
                    Getdata.updatedon = System.DateTimeOffset.Now;
                    Getdata.isdeleted = true;
                    _Db.Entry(Getdata).State = (Microsoft.EntityFrameworkCore.EntityState.Modified);
                    await _Db.SaveChangesAsync();
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 1;
                    cr.responsemessage = "Deleted Successfully";
                    return cr;
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "Invalid id";
                    return cr;
                }
            }
            catch (Exception)
            {
                throw;
            }


        }

        // ============================================================== Admin Edit(Post) ===============================================================
        public async Task<Customresponse> AdminEdit(CustomadminEdit model)
        {
            try
            {
                var Getemail = _Db.admin.Where(x => x.isdeleted == false && x.isactive == true && x.id != model.id && x.email == model.email).SingleOrDefault();
                if (Getemail== null)
                {
                    var Getphone = _Db.admin.Where(x => x.isdeleted == false && x.isactive == true && x.id != model.id && x.phone == model.phone).SingleOrDefault();
                    if (Getphone == null)
                    {
                        var aa = _Db.admin.Where(x => x.isdeleted == false && x.isactive == true && x.id == model.id).SingleOrDefault();
                        if (aa != null)
                        {
                            aa.areacode = model.areacode;
                            aa.address = model.address;
                            aa.email = model.email;
                            aa.phone = model.phone;
                            aa.Name = model.Name;
                            aa.area = model.area;
                            aa.organizationname = model.organizationname;
                            aa.organizationinfomail = model.organizationinfomail;
                            aa.organizationinfomailpassword = model.organizationinfomailpassword;

                            aa.updatedon = System.DateTimeOffset.Now;

                            aa.updatedby = model.authorid;
                            if (model.image != null)
                            {
                                string uniqueFileName = _aws3servies.PostUploadedFile(model.image);
                                aa.image = "https://s3edutech.s3.ap-south-1.amazonaws.com/" + uniqueFileName + "";
                            }
                            _Db.Entry(aa).State = (Microsoft.EntityFrameworkCore.EntityState.Modified);
                            await _Db.SaveChangesAsync();
                            Customresponse cr = new Customresponse();
                            cr.responsecode = 1;
                            cr.responsemessage = "Updated Successfully";
                            return cr;
                        }
                        else
                        {
                            Customresponse cr = new Customresponse();
                            cr.responsecode = 2;
                            cr.responsemessage = "Invalid id";
                            return cr;
                        }
                    }
                    else
                    {
                        Customresponse cr = new Customresponse();
                        cr.responsecode = 2;
                        cr.responsemessage = "Phone Already in Use";
                        return cr;
                    }
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "Email Already in Use";
                    return cr;
                }
                
               
            }
            catch (Exception)
            {
                throw;
            }
        }

        // ============================================================== Admin Index(All Admins Data) ===================================================
        public async Task<IEnumerable<admin>> AdminGetAll()
        {
            try
            {
                return await _Db.admin.Where(x => x.isdeleted == false && x.isactive == true).ToListAsync();
            }
            catch (Exception)
            {
                throw;
            }


        }

        // ============================================================== Admin Data created by authorid =================================================
        public async Task<IEnumerable<admin>> AdminGetByauthor(string authorid)
        {
            try
            {
                return await _Db.admin.Where(x => x.isdeleted == false && x.isactive == true && x.createdby == new Guid(authorid)).ToListAsync();
            }
            catch (Exception)
            {
                throw;
            }

        }

        // ============================================================== Admin (Edit)Get Data using id ==================================================
        public async Task<admin> AdminGetbyId(string id)
        {
            try
            {
                return await _Db.admin.Where(x => x.isdeleted == false && x.isactive == true && x.id == new Guid(id)).SingleOrDefaultAsync();
            }
            catch (Exception)
            {
                throw;
            }

        }

        // ========================================================= Superadmin resetpassword =================================================
        public async Task<Customresponse> postresetpassword(Customresetpassword cc)
        {
            try
            {
                if(cc.currentpassword== _Db.admin.Where(x => x.isdeleted == false && x.isactive == true && x.id == cc.authorid).Select(p=>p.password).SingleOrDefault())
                {
                    if (cc.newpassword == cc.confirmpassword)
                    {
                        var getdata = _Db.admin.Where(x => x.isdeleted == false && x.isactive == true && x.id == cc.authorid).SingleOrDefault();
                        if (getdata != null)
                        {
                            getdata.password = cc.confirmpassword;
                            getdata.updatedby = cc.authorid;
                            getdata.updatedon = System.DateTime.Now;
                            _Db.Entry(getdata).State = EntityState.Modified;
                            await _Db.SaveChangesAsync();
                            Customresponse cr = new Customresponse();
                            cr.responsecode = 1;
                            cr.responsemessage = "Password Successfully Updated";
                            return cr;
                        }
                        else
                        {
                            Customresponse cr = new Customresponse();
                            cr.responsecode = 2;
                            cr.responsemessage = "authorid cann't be null";
                            return cr;
                        }
                    }
                    else
                    {
                        Customresponse cr = new Customresponse();
                        cr.responsecode = 2;
                        cr.responsemessage = "newpassword and confirmpassword doesn't match";
                        return cr;
                    }
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "Please enter the correct current password";
                    return cr;
                }

            }
            catch (Exception)
            {
                throw;
            }
        }



        public async Task<Customresponse> postchangepassword(CustomChangePassword cc)
        {
            try
            {
               
                    if (cc.newpassword == cc.confirmpassword)
                    {
                        var getdata = _Db.admin.Where(x => x.isdeleted == false && x.isactive == true && x.id == cc.authorid).SingleOrDefault();
                        if (getdata != null)
                        {
                            getdata.password = cc.confirmpassword;
                            getdata.updatedby = cc.authorid;
                            getdata.updatedon = System.DateTime.Now;
                            _Db.Entry(getdata).State = EntityState.Modified;
                            await _Db.SaveChangesAsync();
                            Customresponse cr = new Customresponse();
                            cr.responsecode = 1;
                            cr.responsemessage = "Password Successfully Updated";
                            return cr;
                        }
                        else
                        {
                            Customresponse cr = new Customresponse();
                            cr.responsecode = 2;
                            cr.responsemessage = "authorid cann't be null";
                            return cr;
                        }
                    }
                    else
                    {
                        Customresponse cr = new Customresponse();
                        cr.responsecode = 2;
                        cr.responsemessage = "newpassword and confirmpassword doesn't match";
                        return cr;
                    }
            }
            catch (Exception)
            {
                throw;
            }
        }








        // ========================================================= Superadmin forgetpassword =================================================
        public async Task<Customresponse> PostForgetpassword(Customforgetpassword cc)
        {
            try
            {
                var Getdata = _Db.admin.Where(x => x.isdeleted == false && x.isactive == true && x.email == cc.email).SingleOrDefault();
                if (Getdata != null)
                {
                    var otp = _sentEmailSms.forgetpasswordotp(Getdata.Name, Getdata.email, Getdata.phone);
                    Getdata.otp = otp;
                    _Db.Entry(Getdata).State = EntityState.Modified;
                    await _Db.SaveChangesAsync();
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 1;
                    cr.responsemessage = "Otp Successfully Sent";
                    cr.authorid = Getdata.id;
                    return cr;
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "emailid invalid";
                    return cr;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
