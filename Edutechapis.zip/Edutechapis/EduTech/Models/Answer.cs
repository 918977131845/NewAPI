﻿using System;
using System.ComponentModel.DataAnnotations;

namespace EduTech.Models
{
    public class Answer
    {
        [Key]
        public Guid id { get; set; }
        public Guid Assessmentid { get; set; }
        public bool isactive { get; set; }
        public bool isdelete { get; set; }
        public DateTime createdon { get; set; }
        public Guid createdby { get; set; }
        [Required]
        public Guid questionid { get; set; }
        public Guid segmentid { get; set; }
        [Required]
        public Guid subjectid { get; set; }
        [Required]
        public Guid topicid { get; set; }
        public string level { get; set; }
        public Guid gradeid { get; set; }
        public Guid curriculumid { get; set; }
        public string correctanswer { get; set; }
        public string Studentanswer { get; set; }
        
    }
}
