﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.Models
{
    public class segment
    {
        [Key]
        public Guid id { get; set; }
        public Nullable<Guid> createdby { get; set; }
        public Nullable<DateTime> createdon { get; set; }
        public Nullable<Guid> updatedby { get; set; }
        public Nullable<DateTime> updatedon { get; set; }
        public Nullable<bool> isactive { get; set; }
        public Nullable<bool> isdelete { get; set; }
        public string title { get; set; }
        public string imageurl { get; set; }
        public Guid adminid { get; set; }
        public bool isprimary { get; set; }
    }
}
