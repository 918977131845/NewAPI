﻿using System;
using System.ComponentModel.DataAnnotations;

namespace EduTech.Models
{
    public class ExamDay
    {
        [Key]
        public Guid id { get; set; }
        
        public Guid? ExamID { get; set; }
        
        public DateTime CreatedDate { get; set; }

       
        public Guid? Assessmentid { get; set; }
     
        public Guid? Approvedbystudent { get; set; }

    
        public Guid? questiontype { get; set; }

     
        public Guid? segmentid { get; set; }

      
        public Guid? subjectid { get; set; }
       
        public Guid? topicid { get; set; }
       
        public Guid? gradeid { get; set; }
        
        public Guid? curriculumid { get; set; }
        
        public string correctanswer { get; set; }
        
        public string studentanswer { get; set; }
        
        public string questiondata { get; set; }
       
        public string questionname { get; set; }

    }
}
