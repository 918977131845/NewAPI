﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace EduTech.Models
{
    public class userlog
    {
        [Key]
        public Guid id { get; set; }
        public Nullable<Guid> userid { get; set; }

        public Nullable<DateTime> login { get; set; }
        public Nullable<DateTime> logout { get; set; }
        public Nullable<bool> isactive { get; set; }
    }
}
