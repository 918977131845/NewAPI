﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.Models
{
    public class students
    {
        [Key]
        public Guid id { get; set; }
        public string name { get; set; }
        public string email { get; set; }
        public string mobilenumber { get; set; }
        public string grade { get; set; }
        public string course { get; set; }
        public string password { get; set; }
        public Nullable<Guid> createdby { get; set; }
        public Nullable<DateTimeOffset> createdon { get; set; }
        public Nullable<Guid> updatedby { get; set; }
        public Nullable<DateTimeOffset> updatedon { get; set; }
        public bool isactive { get; set; }
        public bool isdeleted { get; set; }
        public string parentname { get; set; }
        public string parentemail { get; set; }
        public string parentphone { get; set; }
        public string dateofbirth { get; set; }
        public string address { get; set; }
        public string studenttype { get; set; }
        public string profilepic { get; set; }
        public string otp { get; set; }
        public string parentmobile { get; set; }
        public string token { get; set; }

    }
}
