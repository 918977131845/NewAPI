﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace EduTech.Models
{
    public class admin
    {
        [Key]
        public Guid id { get; set; }
        public string Name { get; set; }
        public string address { get; set; }
        public double areacode { get; set; }

        public string otp { get; set; }
        [JsonIgnore]
        public string password { get; set; }
        public string email { get; set; }
        public string phone { get; set; }
        public string image { get; set; }
        public string organizationname { get; set; }
        public string organizationinfomail { get; set; }
        public string organizationinfomailpassword { get; set; }
        public Nullable<Guid> createdby { get; set; }
        public Nullable<DateTimeOffset> createdon { get; set; }
        public Nullable<Guid> updatedby { get; set; }
        public Nullable<DateTimeOffset> updatedon { get; set; }
        public bool isactive { get; set; }
        public bool isdeleted { get; set; }
        public string area { get; set; }
        [JsonIgnore]
        public string token { get; set; }
    }
}
