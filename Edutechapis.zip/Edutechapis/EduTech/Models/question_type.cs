﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.Models
{
    public class question_type
    {
        [Key]
        public Guid id { get; set; }
        public string name { get; set; }
        public bool isactive { get; set; }
        public bool isdelete { get; set; }
        public DateTime createdon { get; set; }
        public Guid createdby { get; set; }
        public DateTime modifiedon { get; set; }
        public Guid modifiedby { get; set; }
    }
}
