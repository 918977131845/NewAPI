﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.Models
{
    public class Assessment
    {
        [Key]
        public Guid id { get; set; }
        public Guid segmentid { get; set; }
        public Guid subjectid { get; set; }
        public Guid gradeid { get; set; }
        public Guid carriculum { get; set; }
        public Guid createdby { get; set; }
        public Guid updatedby { get; set; }
        public DateTime createdon { get; set; }
        public DateTime updatedon { get; set; }
        public bool isactive { get; set; }
        public bool isdelete { get; set; }
        public string title { get; set; }
        public Guid Assessmenttype_id { get; set; }
        public double totalquestions { get; set; }
        public double totalmarks { get; set; }
        public double duration_mins { get; set; }
        public double package_duration { get; set; }
        public double price { get; set; }
        public double mocktest { get; set; }
        public double subject_test { get; set; }
        public double topicwise_test { get; set; }
        public double discount { get; set; }
    }
}
