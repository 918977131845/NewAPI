﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace EduTech.Models
{
    public class teacher
    {
        [Key]
        public Guid id { get; set; }
        public string name { get; set; }
        public string email { get; set; }
        public string mobilenumber { get; set; }
        [JsonIgnore]
        public string password { get; set; }
        public string course { get; set; }
        public string subject { get; set; }
        public string otp { get; set; }
        public Nullable<Guid> createdby { get; set; }
        public Nullable<Guid> updatedby { get; set; }
        public Nullable<DateTimeOffset> createdon { get; set; }
        public Nullable<DateTimeOffset> updatedon { get; set; }
        public Nullable<bool> isactive { get; set; }
        public Nullable<bool> isdeleted { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Address { get; set; }
        public string token { get; set; }
    }
}
