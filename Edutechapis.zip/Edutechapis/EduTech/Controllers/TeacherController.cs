﻿using EduTech.CustomModels;
using EduTech.Data;
using EduTech.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.Controllers
{
    [Authorize]
    [ApiController]
    [EnableCors("AllowOrigin")]
    [Route("api/[controller]/[action]")]
    public class TeacherController : Controller
    {
        private readonly ApplicationDbContext _Db;
        private readonly ILogin _login;
        private readonly ITeacherServices _teacher;

        public TeacherController(ApplicationDbContext Db, ITeacherServices teacher, ILogin login)
        {
            _Db = Db;
            _teacher = teacher;
            _login = login;
        }

        // ========================================================== All Teacher's record Method ==================================================

        [HttpGet]
        public async Task<IActionResult> Index(string authorid)
        {
            try
            {
                
                    if (authorid != null)
                    {
                        var Getsuperadminauthor = _Db.superadmin.Where(x => x.isdeleted == false && x.id == new Guid(authorid)).SingleOrDefault();
                        var Getadminauthor = _Db.admin.Where(x => x.isdeleted == false && x.id == new Guid(authorid)).SingleOrDefault();
                        if (Getsuperadminauthor != null)
                        {
                            var Getdata = await _teacher.TeacherGetAll();
                            return Ok(Getdata);
                        }
                        else if (Getadminauthor != null)
                        {
                            var Getdata = await _teacher.TeacherGetByauthor(authorid);
                            return Ok(Getdata);
                        }
                        else
                        {
                            Customresponse cr = new Customresponse();
                            cr.responsecode = 2;
                            cr.responsemessage = "authorid invalid";
                            return Ok(cr);
                        }
                    }
                    else
                    {
                        Customresponse cr = new Customresponse();
                        cr.responsecode = 2;
                        cr.responsemessage = "authorid is null";
                        return Ok(cr);
                    }
               
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        // ========================================================== Teacher Create Method ======================================================= 

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Customteachercreate cc)
        {
            try
            {
                if (ModelState.IsValid)
                {
                   
                        var Getauthor = _Db.admin.Where(x => x.isdeleted == false && x.isactive == true && x.id == cc.authorid).SingleOrDefault();
                        if (Getauthor != null)
                        {
                            var cr = await _teacher.TeacherCreate(cc);
                            return Ok(cr);

                        }
                        else
                        {

                            Customresponse cr = new Customresponse();
                            cr.responsecode = 2;
                            cr.responsemessage = "authorid invalid";
                            return Ok(cr);
                        }
                    
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 4;
                    cr.responsemessage = "Some Required Parameters are Empty";
                    return Ok(cr);
                }

            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        // ========================================================== Teacher EditGet Method ======================================================

        [HttpGet]
        public async Task<IActionResult> Edit(string authorid, string id)
        {
            try
            {
              
                    if (authorid != null)
                    {
                        var Getteacher = _Db.teacher.Where(x => x.isdeleted == false && x.id == new Guid(authorid)).SingleOrDefault();
                        var Getadmin = _Db.admin.Where(x => x.isdeleted == false && x.id == new Guid(authorid)).SingleOrDefault();
                        if (Getteacher != null)
                        {
                            var Getdata = await _teacher.TeacherGetbyId(id);
                            if (Getdata != null)
                            {
                                return Ok(Getdata);
                            }
                            else
                            {
                                Customresponse cr = new Customresponse();
                                cr.responsecode = 2;
                                cr.responsemessage = "Invalid id";
                                return Ok(cr);
                            }

                        }
                        else if (Getadmin != null)
                        {
                            var Getdata = await _teacher.TeacherGetbyId(id);
                            if (Getdata != null)
                            {
                                return Ok(Getdata);
                            }
                            else
                            {
                                Customresponse cr = new Customresponse();
                                cr.responsecode = 2;
                                cr.responsemessage = "Invalid id";
                                return Ok(cr);
                            }
                        }
                        else
                        {
                            Customresponse cr = new Customresponse();
                            cr.responsecode = 2;
                            cr.responsemessage = "authorid does not match";
                            return Ok(cr);
                        }
                    }
                    else
                    {
                        Customresponse cr = new Customresponse();
                        cr.responsecode = 2;
                        cr.responsemessage = "authorid is null";
                        return Ok(cr);
                    }
               
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        // ========================================================== Teacher EditPost Method =====================================================

        [HttpPut]
        public async Task<IActionResult> Edit([FromForm] Customteacher model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                  
                        var Getteacher = _Db.teacher.Where(x => x.isdeleted == false && x.id == model.authorid).SingleOrDefault();
                        var Getadmin = _Db.admin.Where(x => x.isdeleted == false && x.id == model.authorid).SingleOrDefault();
                        if (Getteacher != null)
                        {
                            var cr = await _teacher.TeacherEdit(model);
                            return Ok(cr);
                        }
                        else if (Getadmin != null)
                        {
                            var cr = await _teacher.TeacherEdit(model);
                            return Ok(cr);
                        }
                        else
                        {
                            Customresponse cr = new Customresponse();
                            cr.responsecode = 2;
                            cr.responsemessage = "authorid does not match";
                            return Ok(cr);
                        }
                 
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 4;
                    cr.responsemessage = "Parameters are required";
                    return Ok(cr);
                }
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        // ========================================================= Teacher Delete Method ========================================================

        [HttpPost]
        public async Task<IActionResult> Delete([FromBody] CustomEditGet cc)
        {
            try
            {
               
                    var Getadmin = _Db.admin.Where(x => x.isdeleted == false && x.id == cc.authorid).SingleOrDefault();
                    if (Getadmin != null)
                    {
                        var cr = await _teacher.TeacherDelete(cc.id, cc.authorid);
                        return Ok(cr);
                    }
                    else
                    {
                        Customresponse cr = new Customresponse();
                        cr.responsecode = 2;
                        cr.responsemessage = "authorid does not match";
                        return Ok(cr);
                    }
               
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        // ================================================== Method Used To Reset PassWord ======================================================
        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Changepassword ([FromBody]Customresetpassword cc)
        {
            try
            {
               
                    var cr = await _teacher.postresetpassword(cc);
                    return Ok(cr);

            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }
        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Resetpassword([FromBody] CustomChangePassword cc)
        {
            try
            {

                var cr = await _teacher.postchangepassword(cc);
                return Ok(cr);


            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        // ========================================================= Teacher Login ================================================================
        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Login([FromBody]Customlogin cc)
        {
            try
            {
                var Getauthor = _Db.teacher.Where(x => x.isdeleted == false && x.email == cc.username && x.password == cc.password).SingleOrDefault();
                if (Getauthor != null)
                {
                    var cr = await _login.postlogin(Getauthor.id);
                    return Ok(cr);
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 0;
                    cr.responsemessage = "Username Or PassWord is Incorrect";
                    return Ok(cr);
                }
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        // ======================================================== Teacher Logout ================================================================
        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Logout([FromBody]Customlogout cc)
        {
            try
            {
                var cr = await _login.postlogout(cc.loginid);
                return Ok(cr);
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        // ================================================ Method Used To Forgetpassword =====================================================
        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> ForgetPassword([FromBody]Customforgetpassword cc)
        {
            try
            {
                var cr = await _teacher.PostForgetpassword(cc.email);
                return Ok(cr);
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        // ================================================ Method Used To CheckOtp ===========================================================
        [AllowAnonymous]
        [HttpPost]

        public async Task<IActionResult> CheckOtp([FromBody]Customotp cc)
        {
            try
            {
                var Getcheck = await _Db.teacher.Where(x => x.isdeleted == false && x.id == cc.authorid && x.otp == cc.otp).SingleOrDefaultAsync();
                if (Getcheck != null)
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 1;
                    cr.responsemessage = "Otp Matched Successfully";
                    cr.authorid = Getcheck.id;
                    Getcheck.otp = null;
                    _Db.Entry(Getcheck).State = EntityState.Modified;
                    await _Db.SaveChangesAsync();
                    return Ok(cr);
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "Otp Invalid";
                    return Ok(cr);
                }
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

    }
}
