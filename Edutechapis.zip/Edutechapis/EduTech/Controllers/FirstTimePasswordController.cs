﻿using EduTech.CustomModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System;
using Microsoft.EntityFrameworkCore;
using EduTech.Data;
using EduTech.IServices;
using System.Linq;

namespace EduTech.Controllers
{
    [Authorize]
    [ApiController]
    [EnableCors("AllowOrigin")]
    [Route("api/[controller]/[action]")]
    public class FirstTimePasswordController : ControllerBase
    {
        private readonly ApplicationDbContext _Db;
        private readonly ILogin _login;
        private readonly IAdmin _admin;
        public FirstTimePasswordController(ApplicationDbContext Db, IAdmin admin, ILogin login)
        {
            _Db = Db;
            _admin = admin;
            _login = login;
        }
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> CreateNewPassword([FromBody] Newpassword np)
        {
            try
            {
                var Getcheckadmin = _Db.admin.Where(x => x.isdeleted == false && x.token == np.token).SingleOrDefault();
                var Getcheckteacher = _Db.teacher.Where(x => x.isdeleted == false && x.token == np.token).SingleOrDefault();
                var Getcheckstudent = _Db.students.Where(x => x.isdeleted == false && x.token == np.token).SingleOrDefault();
                if (Getcheckadmin != null)
                {
                    Customresponselogin cr = new Customresponselogin();
                    cr.responsecode = 1;
                    cr.loginType= "Admin";
                    cr.responsemessage = "Password Updated Successfully";
                    //cr.authorid = Getcheckadmin.id;
                    Getcheckadmin.token = null;
                    Getcheckadmin.password = np.newpassword;
                    _Db.Entry(Getcheckadmin).State = EntityState.Modified;
                    await _Db.SaveChangesAsync();
                    return Ok(cr);
                }
                if (Getcheckteacher != null)
                {
                    Customresponselogin cr = new Customresponselogin();
                    cr.responsecode = 1;
                    cr.loginType = "Teacher";
                    cr.responsemessage = "Password Updated Successfully";
                    //cr.authorid = Getcheckteacher.id;
                    Getcheckteacher.token = null;
                    Getcheckteacher.password = np.newpassword;
                    _Db.Entry(Getcheckteacher).State = EntityState.Modified;
                    await _Db.SaveChangesAsync();
                    return Ok(cr);
                }
                if (Getcheckstudent != null)
                {
                    Customresponselogin cr = new Customresponselogin();
                    cr.responsecode = 1;
                    cr.loginType = "Student";
                    cr.responsemessage = "Password Updated Successfully";
                    //cr.authorid = Getcheckstudent.id;
                    Getcheckstudent.token = null;
                    Getcheckstudent.password = np.newpassword;
                    _Db.Entry(Getcheckstudent).State = EntityState.Modified;
                    await _Db.SaveChangesAsync();
                    return Ok(cr);
                }
                else
                {
                    Customresponselogin cr = new Customresponselogin();
                    cr.responsecode = 2;
                    cr.loginType = null;
                    cr.responsemessage = "Token Invalid";
                    return Ok(cr);
                }
            }
            catch (Exception ex)
            {
                Customresponselogin cr = new Customresponselogin();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                cr.loginType = null;
                return Ok(cr);
            }
        }
    }
}
