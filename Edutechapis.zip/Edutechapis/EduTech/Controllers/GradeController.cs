﻿using EduTech.CustomModels;
using EduTech.Data;
using EduTech.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.Controllers
{
    [Authorize]
    [ApiController]
    [EnableCors("AllowOrigin")]

    [Route("api/[controller]/[action]")]
    public class GradeController : ControllerBase
    {
        private readonly ApplicationDbContext _Db;
        private readonly IGradeServices _gradeServices;
        public GradeController(ApplicationDbContext Db, IGradeServices gradeServices)
        {
            _Db = Db;
            _gradeServices = gradeServices;

        }

        [HttpGet]
        public async Task<IActionResult> Index(string authorid)
        {
            try
            {

                var Getauthor = _Db.superadmin.Where(x => x.isdeleted == false && x.id == new Guid(authorid)).SingleOrDefault();
                var Getauthoradmin = _Db.admin.Where(x => x.isdeleted == false && x.id == new Guid(authorid)).SingleOrDefault();
                var Getauthorteacher = _Db.teacher.Where(x => x.isdeleted == false && x.id == new Guid(authorid)).SingleOrDefault();
                if (Getauthor != null)
                {
                    var list = await _gradeServices.GetAllGrade();
                    return Ok(list);
                }
                else if (Getauthoradmin != null)
                {
                    var list = await _gradeServices.GetAllGrade();
                    return Ok(list);
                }
                else if (Getauthorteacher != null)
                {
                    var list = await _gradeServices.GetAllGrade();
                    return Ok(list);
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "authorid is invalid";
                    return Ok(cr);
                }

            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CustomGrade cc)
        {
            try
            {


                var cr = await _gradeServices.PostCreate(cc);
                return Ok(cr);


            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        [HttpPut]
        public async Task<IActionResult> Edit([FromBody] CustomGradeEdit cc)
        {
            try
            {


                var cr = await _gradeServices.PostEdit(cc);
                return Ok(cr);


            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        [HttpPost]
        public async Task<IActionResult> Delete([FromBody] CustomGradeDelete cc)
        {
            try
            {


                var cr = await _gradeServices.PostDelete(cc);
                return Ok(cr);


            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        [HttpGet]
        public async Task<IActionResult> Edit(string id)
        {
            try
            {


                var cr = await _gradeServices.GetIdGrade(new Guid(id));
                return Ok(cr);


            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }
    }
}
