﻿using EduTech.CustomModels;
using EduTech.Data;
using EduTech.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.Controllers
{
    [ApiController]
    [EnableCors("AllowOrigin")]
    [Authorize]
    [Route("api/[controller]/[action]")]
    public class SuperAdminController : ControllerBase
    {
        private readonly ApplicationDbContext _Db;
        private readonly ISuperAdmin _superadmin;
        private readonly ILogin _login;
        public SuperAdminController(ApplicationDbContext Db, ISuperAdmin superadmin, ILogin login)
        {
            _Db = Db;
            _superadmin = superadmin;
            _login = login;
        }

        // =================================================== Method Used To View All SuperAdmin ==============================================

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            try
            {
                var Getdata = await _superadmin.SuperAdminGetAll(); //Method Calling All Superadmin From servies.Admin
                return Ok(Getdata);
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse(); // Method Sent Error Message
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }

        }


        // ================================================== Method Used To Create SuperAdmin ==================================================

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Customsuperadmincreate cc)
        {
            try
            {
                var cr = await _superadmin.Superadmincreate(cc);    // Method Used To Create SuperAdmin
                return Ok(cr);
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();// Method Sent Error Message
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }


        // ================================================== Method Used To (Edit)Put Details Of Single SuperAdmin ==============================

        [HttpPut]
        public async Task<IActionResult> Edit([FromForm] Customsuperadminedit cc)
        {
            try
            {
                var cr = await _superadmin.SuperadminEdit(cc);   // Method Used To Edit SuperAdmin
                return Ok(cr);
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse(); // Method Sent Error Message
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        // ================================================= Method Used To Get Details Of Single SuperAdmin =====================================

        [HttpGet]
        public async Task<IActionResult> Myprofile(string authorid)
        {
            try
            {

                if (authorid != null)
                {
                    var Getdata = await _superadmin.SuperAdminGetbyId(authorid); // Method Used To Edit SuperAdmin
                    return Ok(Getdata);
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "authorid can not be null";
                    return Ok(cr);
                }


            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse(); // Method Sent Error Message
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }


        }

        // ================================================== Method Used To Reset PassWord ======================================================
        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Resetpassword([FromBody] Customresetpassword cc)
        {
            try
            {
                var cr = await _superadmin.postresetpassword(cc);   //calling postresetpassword method in superadmin services
                return Ok(cr);
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        // ================================================= Method Used To Login SuperAdmin =====================================================
        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Login([FromBody] Customlogin cc)
        {
            try
            {
                var Getlogin = _Db.superadmin.Where(x => x.isdeleted == false && x.email == cc.username && x.password == cc.password).SingleOrDefault();
                if (Getlogin != null)
                {
                    var cr = await _login.postlogin(Getlogin.id);
                    return Ok(cr);
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 0;
                    cr.responsemessage = "Username Or PassWord is Incorrect";
                    return Ok(cr);
                }
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }


        }

        // ================================================ Method Used To Logout SuperAdmin =====================================================
        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Logout([FromBody] Customlogout cc)
        {
            try
            {
                var cr = await _login.postlogout(cc.loginid);
                return Ok(cr);
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        // ================================================ Method Used To Forgetpassword =====================================================
        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> ForgetPassword([FromBody] Customforgetpassword cc)
        {
            try
            {
                var cr = await _superadmin.PostForgetpassword(cc);
                return Ok(cr);
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        // ================================================ Method Used To CheckOtp ===========================================================

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> CheckOtp([FromBody] Customotp cc)
        {
            try
            {
                var Getcheck = _Db.superadmin.Where(x => x.isdeleted == false && x.id == cc.authorid && x.otp == cc.otp).SingleOrDefault();
                if (Getcheck != null)
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 1;
                    cr.responsemessage = "Otp Matched Successfully";
                    cr.authorid = Getcheck.id;
                    Getcheck.otp = null;
                    _Db.Entry(Getcheck).State = EntityState.Modified;
                    await _Db.SaveChangesAsync();
                    return Ok(cr);
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "Otp Invalid";
                    return Ok(cr);
                }
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }


        


    }
}
