﻿using EduTech.CustomModels;
using EduTech.Data;
using EduTech.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.Controllers
{
    [Authorize]
    [ApiController]
    [EnableCors("AllowOrigin")]
    [Route("api/[controller]/[action]")]
    public class TopicController : ControllerBase
    {
        private readonly ApplicationDbContext _Db;
        private readonly Itopicservices _topicservices;
        public TopicController(ApplicationDbContext Db, Itopicservices topicservices)
        {
            _Db = Db;
            _topicservices = topicservices;

        }
        [HttpGet]
        public async Task<IActionResult> Index(string authorid)
        {
            try
            {
                var Getauthor = _Db.superadmin.Where(x => x.isdeleted == false && x.id == new Guid(authorid)).SingleOrDefault();
                var Getauthoradmin = _Db.admin.Where(x => x.isdeleted == false && x.id == new Guid(authorid)).SingleOrDefault();
                var Getauthorteacher = _Db.teacher.Where(x => x.isdeleted == false && x.id == new Guid(authorid)).SingleOrDefault();
                if (Getauthor != null)
                {
                    var list = await _topicservices.Getalltopic();
                    return Ok(list);
                }
                else if (Getauthoradmin != null)
                {
                    var list = await _topicservices.Getalltopic();
                    return Ok(list);

                }
                else if (Getauthorteacher != null)
                {
                    var list = await _topicservices.Getalltopic();
                    return Ok(list);
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "authorid is invalid";
                    return Ok(cr);
                }

            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Customtopic cc)
        {
            try
            {
                var cr = await _topicservices.Create(cc); // Method used To Create questiontype
                return Ok(cr);
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        [HttpPost]
        public async Task<IActionResult> Delete([FromBody] CustomtopicDelete cc)
        {
            try
            {
                var cr = await _topicservices.Delete(cc); // Method used To Delete questiontype
                return Ok(cr);
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }
        [HttpGet]
        public async Task<IActionResult> Gettopic(string authorid, string id)
        {
            try
            {
                var Getdata = _Db.admin.Where(x => x.isdeleted == false && x.id == new Guid(authorid)).SingleOrDefault();
                if (Getdata != null)
                {
                    var getdata = await _topicservices.Gettopicbyid(id);
                    return Ok(getdata);
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "you are not authorize";
                    return Ok(cr);
                }

            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }
        [HttpPut]
        public async Task<IActionResult> Edit(Customtopicedit cc)
        {
            try
            {
                var Getauthor = _Db.admin.Where(x => x.isdeleted == false && x.id == cc.id).SingleOrDefault();
                if (Getauthor != null)
                {
                    var cr = await _topicservices.Edit(cc);
                    return Ok(cr);
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "you are not authorize";
                    return Ok(cr);
                }
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }
    }
}
