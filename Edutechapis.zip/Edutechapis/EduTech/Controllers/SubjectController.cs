﻿using EduTech.CustomModels;
using EduTech.Data;
using EduTech.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.Controllers
{

    [ApiController]
    [EnableCors("AllowOrigin")]
    [Authorize]
    [Route("api/[controller]/[action]")]
    public class SubjectController : ControllerBase
    {
        private readonly ApplicationDbContext _Db;
        private readonly ISubjectservices _subjectServices;
        public SubjectController(ApplicationDbContext Db, ISubjectservices subjectServices)
        {
            _Db = Db;
            _subjectServices = subjectServices;

        }

        [HttpGet]
        public async Task<IActionResult> Index(string authorid)
        {
            try
            {
                
                    var Getauthor = _Db.superadmin.Where(x => x.isdeleted == false && x.id == new Guid(authorid)).SingleOrDefault();
                    var Getauthoradmin = _Db.admin.Where(x => x.isdeleted == false && x.id == new Guid(authorid)).SingleOrDefault();
                    var Getauthorteacher = _Db.teacher.Where(x => x.isdeleted == false && x.id == new Guid(authorid)).SingleOrDefault();
                    if (Getauthor != null)
                    {
                        var list = await _subjectServices.GetAllsubject();
                        return Ok(list);
                    }
                    else if (Getauthoradmin != null)
                    {
                        var list = await _subjectServices.GetAllsubject();
                        return Ok(list);
                    }
                    else if (Getauthorteacher != null)
                    {
                        var list = await _subjectServices.GetAllsubject();
                        return Ok(list);
                    }
                    else
                    {
                        Customresponse cr = new Customresponse();
                        cr.responsecode = 2;
                        cr.responsemessage = "authorid is invalid";
                        return Ok(cr);
                    }
                
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Customsubject cc)
        {
            try
            {
               

                    var cr = await _subjectServices.PostCreate(cc);
                    return Ok(cr);


                

            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        [HttpPut]
        public async Task<IActionResult> Edit([FromBody] CustomsubjectEdit cc)
        {
            try
            {
               

                    var cr = await _subjectServices.PostEdit(cc);
                    return Ok(cr);

               
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        [HttpPost]
        public async Task<IActionResult> Delete([FromBody] CustomsubjectDelete cc)
        {
            try
            {
               
                    var cr = await _subjectServices.PostDelete(cc);
                    return Ok(cr);

              
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        [HttpGet]
        public async Task<IActionResult> Edit(string id)
        {
            try
            {
               
                    var cr = await _subjectServices.GetIdsubject(new Guid(id));
                    return Ok(cr);

               
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }
    }
}
