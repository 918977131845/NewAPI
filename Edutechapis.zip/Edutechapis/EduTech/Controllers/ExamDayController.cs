﻿using EduTech.CustomModels;
using EduTech.Data;
using EduTech.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace EduTech.Controllers
{
    //[Route("api/[controller]")]
    //[ApiController]
    [Authorize]
    [ApiController]
    [EnableCors("AllowOrigin")]
    [Route("api/[controller]/[action]")]
    public class ExamDayController : ControllerBase
    {

        private readonly ApplicationDbContext _Db;
        private readonly IExamDay _examDay;

       public ExamDayController(ApplicationDbContext Db, IExamDay ExamDay)
        {
            _Db = Db;
            _examDay = ExamDay; 
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CustomExamDay model)
        {
            try
            {
                var cr = await _examDay.StudentExamDayCreate(model); 
                return Ok(cr);
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

    }
}
