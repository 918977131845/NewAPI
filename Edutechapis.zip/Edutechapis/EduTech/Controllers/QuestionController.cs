﻿using EduTech.CustomModels;
using EduTech.Data;
using EduTech.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Data.Entity.Infrastructure;
using Microsoft.EntityFrameworkCore;

namespace EduTech.Controllers
{
    [Authorize]
    [ApiController]
    [EnableCors("AllowOrigin")]
    [Route("api/[controller]/[action]")]
    public class QuestionController : ControllerBase
    {
        private readonly ApplicationDbContext _Db;
        private readonly Iquestionservices _questionservices;
        public QuestionController(ApplicationDbContext Db, Iquestionservices questionservices)
        {
            _Db = Db;
            _questionservices = questionservices;

        }
        [HttpGet]
        public async Task<IActionResult> Index(string authorid)
        {
            try
            {
                var Getauthor = _Db.superadmin.Where(x => x.isdeleted == false && x.id == new Guid(authorid)).SingleOrDefault();
                var Getauthoradmin = _Db.admin.Where(x => x.isdeleted == false && x.id == new Guid(authorid)).SingleOrDefault();
                var Getauthorteacher = _Db.teacher.Where(x => x.isdeleted == false && x.id == new Guid(authorid)).SingleOrDefault();
                if (Getauthor != null)
                {
                    //var list = await _questionservices.GetAllquestion();
                    var result = (from Qu in _Db.question
                                  join Qt in _Db.question_type on Qu.questiontype equals Qt.id
                                  where Qt.isdelete == false && Qt.isactive == true
                                  join Sb in _Db.subject on Qu.subjectid equals Sb.id
                                  where Sb.isdelete == false && Sb.isactive == true
                                  join Tp in _Db.topic on Qu.topicid equals Tp.id
                                  where Tp.isdelete == false && Tp.isactive == true
                                  join Gr in _Db.Grade on Qu.gradeid equals Gr.id
                                  where Gr.isdelete == false && Gr.isactive == true
                                  join Cr in _Db.curriculum on Qu.curriculumid equals Cr.id
                                  where Cr.isdelete == false && Cr.isactive == true
                                  join Sg in _Db.segment on Qu.segmentid equals Sg.id
                                  where Sg.isdelete == false && Sg.isactive == true
                                  join As in _Db.Assessment on Qu.Assessmentid equals As.id
                                  where As.isdelete == false && As.isactive == true


                                  select new
                                  {
                                      Qu,
                                      Qt,
                                      Sb,
                                      Tp,
                                      Gr,
                                      Cr,
                                      Sg,
                                      As

                                  }).AsQueryable().ToList();


                    return Ok(result);
                }
                else if (Getauthoradmin != null)
                {
                    //var list = await _questionservices.GetAllquestion();


                    var result = (from Qu in _Db.question
                                  join Qt in _Db.question_type on Qu.questiontype equals Qt.id
                                  where Qt.isdelete == false && Qt.isactive == true
                                  join Sb in _Db.subject on Qu.subjectid equals Sb.id
                                  where Sb.isdelete == false && Sb.isactive == true
                                  join Tp in _Db.topic on Qu.topicid equals Tp.id
                                  where Tp.isdelete == false && Tp.isactive == true
                                  join Gr in _Db.Grade on Qu.gradeid equals Gr.id
                                  where Gr.isdelete == false && Gr.isactive == true
                                  join Cr in _Db.curriculum on Qu.curriculumid equals Cr.id
                                  where Cr.isdelete == false && Cr.isactive == true
                                  join Sg in _Db.segment on Qu.segmentid equals Sg.id
                                  where Sg.isdelete == false && Sg.isactive == true
                                  join As in _Db.Assessment on Qu.Assessmentid equals As.id
                                  where As.isdelete == false && As.isactive == true


                                  select new
                                  {
                                      Qu,
                                      Qt,
                                      Sb,
                                      Tp,
                                      Gr,
                                      Cr,
                                      Sg,
                                      As

                                  }).AsQueryable().ToList();


                    return Ok(result);

                }
                else if (Getauthorteacher != null)
                {
                    //var list = await _questionservices.GetAllquestion();
                    var result = (from Qu in _Db.question
                                  join Qt in _Db.question_type on Qu.questiontype equals Qt.id
                                  where Qt.isdelete == false && Qt.isactive == true
                                  join Sb in _Db.subject on Qu.subjectid equals Sb.id
                                  where Sb.isdelete == false && Sb.isactive == true
                                  join Tp in _Db.topic on Qu.topicid equals Tp.id
                                  where Tp.isdelete == false && Tp.isactive == true
                                  join Gr in _Db.Grade on Qu.gradeid equals Gr.id
                                  where Gr.isdelete == false && Gr.isactive == true
                                  join Cr in _Db.curriculum on Qu.curriculumid equals Cr.id
                                  where Cr.isdelete == false && Cr.isactive == true
                                  join Sg in _Db.segment on Qu.segmentid equals Sg.id
                                  where Sg.isdelete == false && Sg.isactive == true
                                  join As in _Db.Assessment on Qu.Assessmentid equals As.id
                                  where As.isdelete == false && As.isactive == true


                                  select new
                                  {
                                      Qu,
                                      Qt,
                                      Sb,
                                      Tp,
                                      Gr,
                                      Cr,
                                      Sg,
                                      As
                                     
                                  }).AsQueryable().ToList();


                    return Ok(result);
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "authorid is invalid";
                    return Ok(cr);
                }

            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Customquestioncreate cc)
        {
            try
            {
                var cr = await _questionservices.Create(cc); // Method used To Create questiontype
                return Ok(cr);
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }

        }
        [HttpPost]
        public async Task<IActionResult> Delete([FromForm] Customquestiondelete cc)
        {
            try
            {
                var cr = await _questionservices.Delete(cc); // Method used To Delete questiontype
                return Ok(cr);
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }
        [HttpGet]
        public async Task<IActionResult> Getquestion(string authorid, string id)
        {
            try
            {
                var Getdata = _Db.admin.Where(x => x.isdeleted == false && x.id == new Guid(authorid)).SingleOrDefault();
                if (Getdata != null)
                {
                    var getdata = await _questionservices.Getquestionbyid(id);
                    return Ok(getdata);
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "you are not authorize";
                    return Ok(cr);
                }

            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }
        [HttpPut]
        public async Task<IActionResult> Edit([FromForm]Customquestionedit cc)
        {
            try
            {
                var Getauthor = _Db.admin.Where(x => x.isdeleted == false && x.id == cc.id).SingleOrDefault();
                if (Getauthor != null)
                {
                    var cr = await _questionservices.Edit(cc);
                    return Ok(cr);
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "you are not authorize";
                    return Ok(cr);
                }
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }
    }
}
