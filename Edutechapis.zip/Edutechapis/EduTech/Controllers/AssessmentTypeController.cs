﻿using EduTech.CustomModels;
using EduTech.Data;
using EduTech.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.Controllers
{
    [Authorize]
    [ApiController]
    [EnableCors("AllowOrigin")]

    [Route("api/[controller]/[action]")]
    public class AssessmentTypeController : ControllerBase
    {
        private readonly ApplicationDbContext _Db;
        private readonly IAssessment_typeservices _assessment_Typeservices;
        public AssessmentTypeController(ApplicationDbContext Db, IAssessment_typeservices assessment_Typeservices)
        {
            _Db = Db;
            _assessment_Typeservices = assessment_Typeservices;

        }


        [HttpGet]
        public async Task<IActionResult> Index(string authorid)
        {
            try
            {
                var Getauthor = _Db.superadmin.Where(x => x.isdeleted == false && x.id == new Guid(authorid)).SingleOrDefault();
                var Getauthoradmin = _Db.admin.Where(x => x.isdeleted == false && x.id == new Guid(authorid)).SingleOrDefault();
                var Getauthorteacher = _Db.teacher.Where(x => x.isdeleted == false && x.id == new Guid(authorid)).SingleOrDefault();
                if (Getauthor != null)
                {
                    var list = await _assessment_Typeservices.GetAssessment_Type();
                    return Ok(list);
                }
                else if (Getauthoradmin != null)
                {
                    var list = await _assessment_Typeservices.GetAssessment_Type();
                    return Ok(list);
                }
                else if (Getauthorteacher != null)
                {
                    var list = await _assessment_Typeservices.GetAssessment_Type();
                    return Ok(list);
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "authorid is invalid";
                    return Ok(cr);
                }
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }


        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Customassessmenttype model)
        {
            try
            {
                var cr = await _assessment_Typeservices.Create(model);
                return Ok(cr);
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

    }
}
