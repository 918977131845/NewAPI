﻿using EduTech.CustomModels;
using EduTech.Data;
using EduTech.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.Controllers
{
    [Authorize]
    [ApiController]
    [EnableCors("AllowOrigin")]
    [Route("api/[controller]/[action]")]
    public class StudentController : ControllerBase
    {
        private readonly ApplicationDbContext _Db;
        private readonly ILogin _login;
        private readonly IStudentservices _student;
        public StudentController(ApplicationDbContext Db, IStudentservices student, ILogin login)
        {
            _Db = Db;
            _student = student;
            _login = login;
        }

        // ================================================================ Admin Get All student =======================================================
        [HttpGet]
        public async Task<IActionResult> Index(string authorid)
        {
            try
            {


                if (authorid != null)
                {
                    var Getadminauthor = _Db.admin.Where(x => x.isdeleted == false && x.id == new Guid(authorid)).SingleOrDefault();  // To Allow only SuperAdmin

                    if (Getadminauthor != null)
                    {
                        var Getdata = await _student.studentsGetByauthor(authorid); // Get All Data of Admin
                        
                        return Ok(Getdata);
                    }
                    else
                    {
                        Customresponse cr = new Customresponse();
                        cr.responsecode = 2;
                        cr.responsemessage = "authorid invalid";
                        return Ok(cr);
                    }
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "authorid is null";
                    return Ok(cr);
                }

            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }

        }

        // =============================================================== Admin Create =========================================================
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Customstudents model)
        {
            try
            {
                if (ModelState.IsValid)
                {



                    if (model.authorid != null)
                    {
                        var cr = await _student.studentcreate(model); // Method used To Create Admin
                        return Ok(cr);
                    }
                    else
                    {
                        var cr = await _student.studentcreatebystudent(model); // Method used To Create Admin
                        return Ok(cr);
                    }

                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 4;
                    cr.responsemessage = "All Fields Required";
                    return Ok(cr);
                }
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        // ============================================================== Admin Get(Edit Get) Details By id =====================================
        [HttpGet]
        public async Task<IActionResult> Myprofile(string authorid, string id)
        {
            try
            {

                if (authorid != null)
                {

                    var Getdata = await _student.studentsGetbyId(id); //Method used To Get details using id
                    if (Getdata != null)
                    {
                        return Ok(Getdata);
                    }
                    else
                    {
                        Customresponse cr = new Customresponse();
                        cr.responsecode = 2;
                        cr.responsemessage = "Invalid Id";
                        return Ok(cr);
                    }


                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "authorid is null";
                    return Ok(cr);
                }

            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        // ============================================================== Admin Update(Edit Post) By id ========================================== 
        [HttpPut]
        public async Task<IActionResult> Edit([FromForm] Customstudentsedit model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var cr = await _student.studentEdit(model); //Method used To Post details using id
                    return Ok(cr);
                }
                else
                {
                    return Ok("SomeThing Went Wrong");
                }
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        // ================================================== Method Used To Reset PassWord ======================================================
        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Changepassword ([FromBody] Customresetpassword cc)
        {
            try
            {

                var cr = await _student.postresetpassword(cc);
                return Ok(cr);


            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }
        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Resetpassword([FromBody] CustomChangePassword cc)
        {
            try
            {

                var cr = await _student.postchangepassword(cc);
                return Ok(cr);


            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        // =============================================================== Admin Login ===========================================================
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> Login([FromBody] Customlogin cc)
        {
            try
            {
                var Getlogin = _Db.students.Where(x => x.isdeleted == false && x.email == cc.username && x.password == cc.password).SingleOrDefault();
                if (Getlogin != null)
                {
                    var cr = await _login.postlogin(Getlogin.id);
                    return Ok(cr);
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 0;
                    cr.responsemessage = "Username Or PassWord is Incorrect";
                    return Ok(cr);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(String.Concat(e.StackTrace, e.Message));

                if (e.InnerException != null)
                {
                    Console.WriteLine("Inner Exception");
                    Console.WriteLine(String.Concat(e.InnerException.StackTrace, e.InnerException.Message));
                }
            }
            Console.ReadLine();
            return Ok();
        }

        // =============================================================== Admin Logout ==========================================================
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> Logout([FromBody] Customlogout cc)
        {
            try
            {
                var cr = await _login.postlogout(cc.loginid);
                return Ok(cr);
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        // ================================================ Method Used To Forgetpassword =====================================================

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> ForgetPassword([FromBody] Customforgetpassword cc)
        {
            try
            {
                var cr = await _student.PostForgetpassword(cc);
                return Ok(cr);
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }

        // ================================================ Method Used To CheckOtp ===========================================================

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> CheckOtp([FromBody] Customotp cc)
        {
            try
            {
                var Getcheck = await _Db.students.Where(x => x.isdeleted == false && x.id == cc.authorid && x.otp == cc.otp).SingleOrDefaultAsync();
                if (Getcheck != null)
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 1;
                    cr.responsemessage = "Otp Matched Successfully";
                    cr.authorid = Getcheck.id;
                    Getcheck.otp = null;
                    _Db.Entry(Getcheck).State = EntityState.Modified;
                    await _Db.SaveChangesAsync();
                    return Ok(cr);
                }
                else
                {
                    Customresponse cr = new Customresponse();
                    cr.responsecode = 2;
                    cr.responsemessage = "Otp Invalid";
                    return Ok(cr);
                }
            }
            catch (Exception ex)
            {
                Customresponse cr = new Customresponse();
                cr.responsecode = 6;
                cr.responsemessage = ex.Message;
                return Ok(cr);
            }
        }
    }
}
