﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EduTech.Migrations
{
    /// <inheritdoc />
    public partial class ExamDaytable1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "examDays",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ExamID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Assessmentid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Approvedbystudent = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    questiontype = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    segmentid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    subjectid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    topicid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    gradeid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    curriculumid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    correctanswer = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    studentanswer = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    questiondata = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    questionname = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_examDays", x => x.id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "examDays");
        }
    }
}
