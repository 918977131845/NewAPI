﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace EduTech.Migrations
{
    public partial class InitialMG : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "admin",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    address = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    areacode = table.Column<double>(type: "float", nullable: false),
                    otp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    password = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    phone = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    image = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    organizationname = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    organizationinfomail = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    organizationinfomailpassword = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    createdby = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    createdon = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    updatedby = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    updatedon = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    isactive = table.Column<bool>(type: "bit", nullable: false),
                    isdeleted = table.Column<bool>(type: "bit", nullable: false),
                    area = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_admin", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Assessment",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    segmentid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    subjectid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    gradeid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    carriculum = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    createdby = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    updatedby = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    createdon = table.Column<DateTime>(type: "datetime2", nullable: false),
                    updatedon = table.Column<DateTime>(type: "datetime2", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false),
                    isdelete = table.Column<bool>(type: "bit", nullable: false),
                    title = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Assessmenttype_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    totalquestions = table.Column<double>(type: "float", nullable: false),
                    totalmarks = table.Column<double>(type: "float", nullable: false),
                    duration_mins = table.Column<double>(type: "float", nullable: false),
                    package_duration = table.Column<double>(type: "float", nullable: false),
                    price = table.Column<double>(type: "float", nullable: false),
                    mocktest = table.Column<double>(type: "float", nullable: false),
                    subject_test = table.Column<double>(type: "float", nullable: false),
                    topicwise_test = table.Column<double>(type: "float", nullable: false),
                    discount = table.Column<double>(type: "float", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Assessment", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Assessment_type",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false),
                    isdelete = table.Column<bool>(type: "bit", nullable: false),
                    createdon = table.Column<DateTime>(type: "datetime2", nullable: false),
                    createdby = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Modifiedon = table.Column<DateTime>(type: "datetime2", nullable: false),
                    modifiedby = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Totalmarks = table.Column<double>(type: "float", nullable: false),
                    Eachquestion_correctmarks = table.Column<double>(type: "float", nullable: false),
                    Eachquestion_negativemarking = table.Column<double>(type: "float", nullable: false),
                    instructions = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    adminid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Assessmenttype_name = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Assessment_type", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "curriculum",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    createdby = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    createdon = table.Column<DateTime>(type: "datetime2", nullable: true),
                    updatedby = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    updatedon = table.Column<DateTime>(type: "datetime2", nullable: true),
                    isactive = table.Column<bool>(type: "bit", nullable: true),
                    isdelete = table.Column<bool>(type: "bit", nullable: true),
                    gradeid = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    segmentid = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    title = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    imageurl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    adminid = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    isprimary = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_curriculum", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Grade",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    segmentid = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    createdby = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    createdon = table.Column<DateTime>(type: "datetime2", nullable: true),
                    updatedby = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    updatedon = table.Column<DateTime>(type: "datetime2", nullable: true),
                    isactive = table.Column<bool>(type: "bit", nullable: true),
                    isdelete = table.Column<bool>(type: "bit", nullable: true),
                    title = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    imageurl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    adminid = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    isprimary = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Grade", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "question",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Assessmentid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false),
                    isdelete = table.Column<bool>(type: "bit", nullable: false),
                    createdon = table.Column<DateTime>(type: "datetime2", nullable: false),
                    createdby = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    questiontype = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    segmentid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    subjectid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    topicid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    level = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    questionname = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    gradeid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    curriculumid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    correctanswer = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_question", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "question_type",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    isactive = table.Column<bool>(type: "bit", nullable: false),
                    isdelete = table.Column<bool>(type: "bit", nullable: false),
                    createdon = table.Column<DateTime>(type: "datetime2", nullable: false),
                    createdby = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    modifiedon = table.Column<DateTime>(type: "datetime2", nullable: false),
                    modifiedby = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_question_type", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "segment",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    createdby = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    createdon = table.Column<DateTime>(type: "datetime2", nullable: true),
                    updatedby = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    updatedon = table.Column<DateTime>(type: "datetime2", nullable: true),
                    isactive = table.Column<bool>(type: "bit", nullable: true),
                    isdelete = table.Column<bool>(type: "bit", nullable: true),
                    title = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    imageurl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    adminid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    isprimary = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_segment", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "students",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    mobilenumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    grade = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    course = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    password = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    createdby = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    createdon = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    updatedby = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    updatedon = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    isactive = table.Column<bool>(type: "bit", nullable: false),
                    isdeleted = table.Column<bool>(type: "bit", nullable: false),
                    parentname = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    parentemail = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    parentphone = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    dateofbirth = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    address = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    studenttype = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    profilepic = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    otp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    parentmobile = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    token = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_students", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "subject",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    segmentid = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    gradeid = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    carriculum = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    createdby = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    updatedby = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    createdon = table.Column<DateTime>(type: "datetime2", nullable: true),
                    updatedon = table.Column<DateTime>(type: "datetime2", nullable: true),
                    isactive = table.Column<bool>(type: "bit", nullable: true),
                    isdelete = table.Column<bool>(type: "bit", nullable: true),
                    title = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    imageurl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    adminid = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    isprimary = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_subject", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "superadmin",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    password = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    phone = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    image = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    otp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    isactive = table.Column<bool>(type: "bit", nullable: true),
                    isdeleted = table.Column<bool>(type: "bit", nullable: true),
                    createdby = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    updatedby = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    createdon = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                    updatedon = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_superadmin", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "teacher",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    mobilenumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    password = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    course = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    subject = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    otp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    createdby = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    updatedby = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    createdon = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    updatedon = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    isactive = table.Column<bool>(type: "bit", nullable: true),
                    isdeleted = table.Column<bool>(type: "bit", nullable: true),
                    DateOfBirth = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    token = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_teacher", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "topic",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false),
                    isdelete = table.Column<bool>(type: "bit", nullable: false),
                    createdon = table.Column<DateTime>(type: "datetime2", nullable: false),
                    createdby = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    modifiedon = table.Column<DateTime>(type: "datetime2", nullable: false),
                    modifiedby = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    segmentid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    gradeid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    curriculumid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    subjectid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    assessmenttypeid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    topic_name = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_topic", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "userlog",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    userid = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    login = table.Column<DateTime>(type: "datetime2", nullable: true),
                    logout = table.Column<DateTime>(type: "datetime2", nullable: true),
                    isactive = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_userlog", x => x.id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "admin");

            migrationBuilder.DropTable(
                name: "Assessment");

            migrationBuilder.DropTable(
                name: "Assessment_type");

            migrationBuilder.DropTable(
                name: "curriculum");

            migrationBuilder.DropTable(
                name: "Grade");

            migrationBuilder.DropTable(
                name: "question");

            migrationBuilder.DropTable(
                name: "question_type");

            migrationBuilder.DropTable(
                name: "segment");

            migrationBuilder.DropTable(
                name: "students");

            migrationBuilder.DropTable(
                name: "subject");

            migrationBuilder.DropTable(
                name: "superadmin");

            migrationBuilder.DropTable(
                name: "teacher");

            migrationBuilder.DropTable(
                name: "topic");

            migrationBuilder.DropTable(
                name: "userlog");
        }
    }
}
