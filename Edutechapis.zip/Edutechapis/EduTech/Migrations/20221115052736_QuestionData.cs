﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace EduTech.Migrations
{
    public partial class QuestionData : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "questiondata",
                table: "question",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "questiondata",
                table: "question");
        }
    }
}
