﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EduTech.Migrations
{
    /// <inheritdoc />
    public partial class AddedAnswertbl : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Answers",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Assessmentid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    isactive = table.Column<bool>(type: "bit", nullable: false),
                    isdelete = table.Column<bool>(type: "bit", nullable: false),
                    createdon = table.Column<DateTime>(type: "datetime2", nullable: false),
                    createdby = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    questionid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    segmentid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    subjectid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    topicid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    level = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    gradeid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    curriculumid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    correctanswer = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Studentanswer = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Answers", x => x.id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Answers");
        }
    }
}
