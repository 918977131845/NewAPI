﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EduTech.Migrations
{
    /// <inheritdoc />
    public partial class AddedColumnInAssessmentType : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<double>(
                name: "Discount",
                table: "Assessment_type",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<DateTime>(
                name: "Duration",
                table: "Assessment_type",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<double>(
                name: "MockTest",
                table: "Assessment_type",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<DateTime>(
                name: "PackageDuration",
                table: "Assessment_type",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<double>(
                name: "Price",
                table: "Assessment_type",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "SubjectTest",
                table: "Assessment_type",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<int>(
                name: "TopicWiseTest",
                table: "Assessment_type",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<double>(
                name: "TotalQuestions",
                table: "Assessment_type",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<Guid>(
                name: "curriculumid",
                table: "Assessment_type",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "gradeid",
                table: "Assessment_type",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "segmentid",
                table: "Assessment_type",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "subjectid",
                table: "Assessment_type",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "topicid",
                table: "Assessment_type",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Discount",
                table: "Assessment_type");

            migrationBuilder.DropColumn(
                name: "Duration",
                table: "Assessment_type");

            migrationBuilder.DropColumn(
                name: "MockTest",
                table: "Assessment_type");

            migrationBuilder.DropColumn(
                name: "PackageDuration",
                table: "Assessment_type");

            migrationBuilder.DropColumn(
                name: "Price",
                table: "Assessment_type");

            migrationBuilder.DropColumn(
                name: "SubjectTest",
                table: "Assessment_type");

            migrationBuilder.DropColumn(
                name: "TopicWiseTest",
                table: "Assessment_type");

            migrationBuilder.DropColumn(
                name: "TotalQuestions",
                table: "Assessment_type");

            migrationBuilder.DropColumn(
                name: "curriculumid",
                table: "Assessment_type");

            migrationBuilder.DropColumn(
                name: "gradeid",
                table: "Assessment_type");

            migrationBuilder.DropColumn(
                name: "segmentid",
                table: "Assessment_type");

            migrationBuilder.DropColumn(
                name: "subjectid",
                table: "Assessment_type");

            migrationBuilder.DropColumn(
                name: "topicid",
                table: "Assessment_type");
        }
    }
}
