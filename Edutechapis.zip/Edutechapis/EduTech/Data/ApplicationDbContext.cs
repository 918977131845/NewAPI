﻿using EduTech.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.Data
{
    public class ApplicationDbContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //base.OnConfiguring(optionsBuilder);
           // optionsBuilder.UseSqlServer(@"Server=DINESH;Initial Catalog=Edutech;User ID=sa;Password=dinesh;");
        }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
         
        }
        public  DbSet<admin> admin { get; set; }
        public   DbSet<superadmin> superadmin { get; set; }
        public  DbSet<userlog> userlog { get; set; }
        public DbSet<teacher> teacher { get; set; }
        public DbSet<segment> segment { get; set; }
        public DbSet<Grade> Grade { get; set; }
        public DbSet<curriculum> curriculum { get; set; }
        public DbSet<subject> subject { get; set; }
        public DbSet<Assessment_type> Assessment_type  { get; set; }
        public DbSet<students> students { get; set; }
        public DbSet<Assessment> Assessment { get; set; }
        public DbSet<question_type> question_type { get; set; }
        public DbSet<topic> topic { get; set; }
        public DbSet<question> question { get; set; }
        public DbSet<ExamDay> examDays { get; set; }
        public DbSet<Answer> Answers { get; set; }
    }

}
