﻿using EduTech.CustomModels;
using EduTech.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.IServices
{
    public interface IAssessment_typeservices
    {
        Task<IEnumerable<Assessment_type>> GetAssessment_Type();
        Task<Customresponse> Create(Customassessmenttype model);
    }
        
}
