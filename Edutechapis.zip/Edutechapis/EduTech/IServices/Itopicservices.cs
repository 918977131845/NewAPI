﻿using EduTech.CustomModels;
using EduTech.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.IServices
{
    public interface Itopicservices
    {
        Task<Customresponse> Create(Customtopic cc);
        Task<Customresponse> Edit(Customtopicedit cc);
        Task<Customresponse> Delete(CustomtopicDelete cc);
        Task<topic> Gettopicbyid(string id);
        Task<IEnumerable<topic>> Getalltopic();
    }
}
