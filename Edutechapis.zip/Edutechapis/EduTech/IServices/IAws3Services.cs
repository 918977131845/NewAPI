﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.IServices
{
    public interface IAws3Services
    {
        string PostUploadedFile(IFormFile image);
        string PostUploadedFile(string fileName, IFormFile image);
    }
}
