﻿using EduTech.CustomModels;
using EduTech.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EduTech.IServices
{
    public interface ISubjectservices
    {
        Task<Customresponse> PostCreate(Customsubject cc);

        Task<Customresponse> PostEdit(CustomsubjectEdit cc);

        Task<Customresponse> PostDelete(CustomsubjectDelete cc);
        Task<IEnumerable<subject>> GetAllsubject();

        Task<subject> GetIdsubject(Guid id);

        Task<IEnumerable<subject>> GetsubjectByauthorid(string authorid);

        Task<IEnumerable<subject>> Getsubjectbyadminid(Guid authorid);
    }
}
