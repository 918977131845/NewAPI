﻿using EduTech.CustomModels;
using EduTech.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.IServices
{
    public interface IAdmin
    {

        Task<Customresponse> Admincreate(CustomadminCreate model);
        Task<Customresponse> AdminEdit(CustomadminEdit model);
        Task<Customresponse> AdminDelete(Guid id, Guid authorid);
        Task<IEnumerable<admin>> AdminGetAll();
        Task<admin> AdminGetbyId(string id);
        Task<IEnumerable<admin>> AdminGetByauthor(string authorid);
        Task<Customresponse> postresetpassword(Customresetpassword cc);
        Task<Customresponse> postchangepassword(CustomChangePassword cc);
        Task<Customresponse> PostForgetpassword(Customforgetpassword cc);
    }
}
