﻿using EduTech.CustomModels;
using EduTech.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EduTech.IServices
{
    public interface ICurriculumservices
    {
        Task<Customresponse> PostCreate(CustomCurriculum cc);

        Task<Customresponse> PostEdit(CustomCurriculumEdit cc);

        Task<Customresponse> PostDelete(CustomCurriculumDelete cc);
        Task<IEnumerable<curriculum>> GetAllCurriculum();

        Task<curriculum> GetIdCurriculum(Guid id);

        Task<IEnumerable<curriculum>> GetCurriculumByauthorid(string authorid);

        Task<IEnumerable<curriculum>> GetCurriculumbyadminid(Guid authorid);
    }
}
