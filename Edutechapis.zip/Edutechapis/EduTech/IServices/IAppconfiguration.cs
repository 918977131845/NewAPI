﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.IServices
{
	public interface IAppConfiguration
	{
		string AwsAccessKey { get; set; }
		string AwsSecretAccessKey { get; set; }
	
		string BucketName { get; set; }
		string Region { get; set; }
	}
}
