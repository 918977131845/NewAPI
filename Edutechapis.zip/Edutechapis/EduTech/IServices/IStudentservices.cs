﻿using EduTech.CustomModels;
using EduTech.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EduTech.IServices
{
    public interface IStudentservices
    {
        Task<Customresponse> studentcreate(Customstudents model);
        Task<Customresponse> studentcreatebystudent(Customstudents model);
        Task<Customresponse> studentEdit(Customstudentsedit model);
        Task<Customresponse> studentDelete(string id, string authorid);
        Task<IEnumerable<students>> studentsGetAll();
        Task<students> studentsGetbyId(string id);
        Task<IEnumerable<students>> studentsGetByauthor(string authorid);
        Task<Customresponse> postresetpassword(Customresetpassword cc);
        Task<Customresponse> postchangepassword(CustomChangePassword cc);
        Task<Customresponse> PostForgetpassword(Customforgetpassword cc);
    }
}
