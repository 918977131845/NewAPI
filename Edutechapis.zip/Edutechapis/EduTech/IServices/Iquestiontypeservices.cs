﻿using EduTech.CustomModels;
using EduTech.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.IServices
{
    public interface Iquestiontypeservices
    {
        Task<Customresponse> Create(Customquestiontype cc);
        Task<Customresponse> Edit(Customquestiontypeedit cc);
        Task<Customresponse> Delete(CustomquestiontypeDelete cc);
        Task<question_type> Getquestiontypebyid(string id);
        Task<IEnumerable<question_type>> Getallquestiontype();
    }
}
