﻿using EduTech.CustomModels;
using EduTech.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.IServices
{
    public interface IGradeServices
    {
        Task<Customresponse> PostCreate(CustomGrade cc);

        Task<Customresponse> PostEdit(CustomGradeEdit cc);

        Task<Customresponse> PostDelete(CustomGradeDelete cc);
        Task<IEnumerable<Grade>> GetAllGrade();

        Task<Grade> GetIdGrade(Guid id);

        Task<IEnumerable<Grade>> GetGradeByauthorid(string authorid);

        Task<IEnumerable<Grade>> GetGradebyadminid(Guid authorid);
    }
}
