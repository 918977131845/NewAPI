﻿using EduTech.CustomModels;
using EduTech.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.IServices
{
    public interface ISegmentServices
    {
        Task<Customresponse> PostCreate(CustomSegment cc);

        Task<Customresponse> PostEdit(CustomSegmentEdit cc);

        Task<Customresponse> PostDelete(CustomSegmentDelete cc);

        Task<IEnumerable<segment>> GetAllsegment();

        Task<segment> GetIdsegment(Guid id);

        Task<IEnumerable<segment>> GetsegmentByauthorid(string authorid);

        Task<IEnumerable<segment>> Getsegmentbyadminid(Guid authorid);
    }
}
