﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.IServices
{
    public interface ISentEmailSms
    {
        void SuperadminSentEmailSms(string name, string email, string password, string phone);

        string forgetpasswordotp(string name, string email, string phone);

        void SendEmailTecherORStudent(string name, string email, string token);
    }
}
