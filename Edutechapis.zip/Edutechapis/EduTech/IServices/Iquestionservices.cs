﻿using EduTech.CustomModels;
using EduTech.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.IServices
{
    public interface Iquestionservices
    {
        Task<Customresponse> Create(Customquestioncreate cc);
        Task<Customresponse> Edit(Customquestionedit cc);
        Task<Customresponse> Delete(Customquestiondelete cc);
        Task<IEnumerable<question>> GetAllquestion();
        Task<question> Getquestionbyid(string id);
    }
}
