﻿using EduTech.CustomModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.IServices
{
    public interface ILogin
    {
         Task<Customresponse> postlogin(Guid id);

         Task<Customresponse> postlogout(Guid loginid);

      
    }
}
