﻿using EduTech.CustomModels;
using System.Threading.Tasks;

namespace EduTech.IServices
{
    public interface IExamDay
    {
        Task<Customresponse> StudentExamDayCreate(CustomExamDay model);
    }
}
