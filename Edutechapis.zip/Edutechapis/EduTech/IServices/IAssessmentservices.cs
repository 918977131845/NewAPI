﻿using EduTech.CustomModels;
using EduTech.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.IServices
{
    public interface IAssessmentservices
    {
        Task<Customresponse> Create(CustomAssessment cc);
        Task<Customresponse> Edit(CustomAssessmentedit cc);
        Task<Customresponse> Delete(CustomAssessmentDelete cc);
        Task<IEnumerable<Assessment>> GetAllAssessment();
        Task<Assessment> GetAssessmentbyid(string id);

    }
}
