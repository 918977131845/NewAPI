﻿using EduTech.CustomModels;
using EduTech.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.IServices
{
    public interface ISuperAdmin
    {
        Task<Customresponse> Superadmincreate(Customsuperadmincreate cc);
        Task<Customresponse> SuperadminEdit(Customsuperadminedit cc);
        void SuperadminDelete(string id, string authorid);
        Task<IEnumerable<superadmin>> SuperAdminGetAll();
        Task<superadmin> SuperAdminGetbyId(string authorid);
        Task<IEnumerable<superadmin>> SuperAdminGetByauthor(string authorid);
        Task<Customresponse> postresetpassword(Customresetpassword cc);

        Task<Customresponse> PostForgetpassword(Customforgetpassword cc);
    }
}
