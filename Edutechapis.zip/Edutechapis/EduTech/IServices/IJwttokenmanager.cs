﻿namespace EduTech.IServices
{
    public interface IJwttokenmanager
    {
        string Authenticate(string id);
    }
}
