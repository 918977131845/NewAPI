﻿using EduTech.CustomModels;
using EduTech.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EduTech.IServices
{
    public interface ITeacherServices
    {
        Task<IEnumerable<teacher>> TeacherGetAll();
        Task<Customresponse> TeacherCreate(Customteachercreate cc);
        Task<teacher> TeacherGetbyId(string id);
        Task<Customresponse> TeacherEdit(Customteacher cc);
        Task<Customresponse> TeacherDelete(Guid id, Guid authorid);
        Task<IEnumerable<teacher>> TeacherGetByauthor(string authorid);

        Task<Customresponse> postresetpassword(Customresetpassword cc);

        Task<Customresponse> postchangepassword(CustomChangePassword cc);
        Task<Customresponse> PostForgetpassword(string email);
    }
}
